#include <stdio.h>
#include <conio.h>
#include <windows.h>
#define ligne 10
#define colonne 20

void gotoligcol(int x, int y) {
    // Implementation of gotoligcol function
}
void affichage(char matrice[ligne][colonne])
{
    for (int i = 0; i < ligne; i++) {
        for (int j = 0; j < colonne; j++) {
            printf("%c", matrice[i][j]);
        }
        printf("\n");  // Passer à la ligne suivante
    }
}
int main() {
    char matrice[ligne][colonne];
    int x = 5 , y = 10, X1=1, Y1=1, X2=1, Y2=18, X3=8, Y3=18, X4=8, Y4=1, X5=4, Y5=12;
    char noopy = 'S';
    char oiseau1 = 'O',oiseau2 = 'O' ,oiseau3 = 'O', oiseau4 = 'O', blocpiege = 'P', blocfixe = 'F';

    // Créer la matrice et remplir chaque élément avec un espace
    for (int i = 0; i < ligne; i++) {
        for (int j = 0; j < colonne; j++) {
            matrice[i][j] = ' ';
        }
    }
    int hauteurRectangle = 10;
    int largeurRectangle = 20;
    int ligneDebut = 0;
    int colonneDebut = 0;

    for (int i = ligneDebut; i < ligneDebut + hauteurRectangle; i++) {
        for (int j = colonneDebut; j < colonneDebut + largeurRectangle; j++) {
            if (i == ligneDebut || i == ligneDebut + hauteurRectangle - 1 || j == colonneDebut ||
                j == colonneDebut + largeurRectangle - 1) {
                matrice[i][j] = 44;  // Remplit uniquement les bords du rectangle
            }
        }
    }

    matrice[x][y] = noopy;
    matrice[X1][Y1] = oiseau1;
    matrice[X2][Y2] = oiseau2;
    matrice[X3][Y3] = oiseau3;
    matrice[X4][Y4] = oiseau4;
    matrice[X5][Y5] = blocpiege;
    affichage(matrice);
int touche;
    do
    {
        printf("Quel est votre direction ?\n"
               "z:Haut q:Gauche s:Bas d:Droite e:Fin\n");
        do
        {
            scanf("%c",&touche);
        }while(!(touche == 'q'||touche == 'z'||touche == 'd'||touche == 's'|| touche =='e'));
        system("cls");
        //séléction de la direction
        switch(touche)
        {
            //Mouv HAUT
            case 'q':
            {
                //vérifiaction de la possibilité d'execution du mouvement en cas de bordure ou de bloc fixe
                if(matrice[x][y-1] == blocfixe||matrice[x][y-1] == matrice[ligneDebut][colonneDebut])
                {
                    printf("Le mouvement n'est pas possible\n");
                    affichage(matrice);
                }
                    //déplacement permis si aucune autre condition n'est validé
                else
                {
                    printf("le mouvement est vers le haut\n");
                    //effacement de la position antèrieur
                    matrice[x][y] = ' ';
                    //déplacement vers le haut
                    matrice[x][y-1] = noopy;
                    //incrémentation pour la valeur initale suivante
                    y--;
                    //affichage de la modification
                    affichage(matrice);
                }
                break;
            }
                //Mouv GAUCHE
            case 'z':
            {
                //vérifiaction de la possibilité d'execution du mouvement
                if(matrice[x-1][y] == blocfixe||matrice[x-1][y] == matrice[ligneDebut][colonneDebut])
                {
                    printf("Le mouvement n'est pas possible\n");
                    affichage(matrice);
                }
                else
                {
                    printf("le mouvement est vers la gauche\n");
                    //effacement de la position antèrieur
                    matrice[x][y] = ' ';
                    //déplacement vers la gauche
                    matrice[x-1][y] = noopy;
                    //incrémentation pour la valeur initale suivante
                    x--;
                    //affichage de la modification
                    affichage(matrice);
                }
                break;
            }
                //Mouv BAS
            case 'd':
            {
                //vérifiaction de la possibilité d'execution du mouvement
                if(matrice[x][y+1] == blocfixe||matrice[x][y+1] == matrice[ligneDebut][colonneDebut])
                {
                    printf("Le mouvement n'est pas possible\n");
                    affichage(matrice);
                }
                else
                {
                    printf("le mouvement est vers le bas\n");
                    //effacement de la position antèrieur
                    matrice[x][y] = ' ';
                    //déplacement vers le bas
                    matrice[x][y+1] = noopy;
                    //incrémentation pour la valeur initale suivante
                    y++;
                    //affichage de la modification
                    affichage(matrice);
                }
                break;
            }
                //Mouv DROITE
            case 's':
            {
                //vérifiaction de la possibilité d'execution du mouvement
                if(matrice[x+1][y] == blocfixe||matrice[x+1][y] == matrice[ligneDebut][colonneDebut])
                {
                    printf("Le mouvement n'est pas possible\n");
                    affichage(matrice);
                }
                else
                {
                    printf("le mouvement est vers la droite\n");
                    //effacement de la position antèrieur
                    matrice[x][y] = ' ';
                    //déplacement vers le haut
                    matrice[x+1][y] = noopy;
                    //incrémentation pour la valeur initale suivante
                    x++;
                    //affichage de la modification
                    affichage(matrice);
                }
                break;
            }
        }
    }while(touche != 'e');
    return 0;
}

