#include <stdio.h>
#include <string.h>
#include <unistd.h>

const int TEMPS_JEU = 120;

struct profil {
    char identifiant[100];
    char MDP[100];
    char pseudo[100];
};

// Déclaration des fonctions
void reglesDuJeu(void);
void nouveauJeu(void);
void chargerPartie(void);
void motDePasse(void);
void scores(void);

int Menu() {
    int choix;
    printf("***********************************************\n");
    printf("****************** SNOOPY GAME ****************\n");
    printf("***********************************************\n");
    printf("1. REGLES DU JEU\n");
    printf("2. NOUVEAU JEU\n");
    printf("3. CHARGER UNE PARTIE\n");
    printf("4. MOT DE PASSE\n");
    printf("5. SCORES\n");
    printf("6. QUITTER\n");
    printf("***********************************************\n");
    printf("***********************************************\n");

    scanf("%d", &choix);

    switch (choix) {
        case 1:
            reglesDuJeu();
            break;
        case 2:
            nouveauJeu();
            break;
        case 3:
            chargerPartie();
            break;
        case 4:
            motDePasse();
            break;
        case 5:
            scores();
            break;
        case 6:
            printf("Au revoir !\n");
            break;
        default:
            printf("Choix non valide\n");
            break;
    }

    return 0;
}

// Fonction pour afficher les règles du jeu
void reglesDuJeu(void) {
    printf("Le but de Snoopy est de récupérer 4 oiseaux aux 4 coins du niveau en un temps imparti. Le problème\n"
           "est que ces 4 oiseaux ne sont pas si faciles à récupérer. Une balle rebondit constamment dans le niveau\n"
           "afin de freiner Snoopy dans sa quête. Mais ce n'est pas tout, d'autres pièges sont présents comme des\n"
           "téléporteurs que la balle peut emprunter ou des cases piégées, voir même des blocs à pousser ou à\n"
           "casser...\n");
}

// Fonction pour commencer un nouveau jeu
void nouveauJeu(void) {
    int connexion(struct profil profil){
        char identifiantDeCo[100];
        char MDPDeCo[100];
        printf("Identifiant : ");
        scanf("%s", identifiantDeCo);
        printf("Mot de passe : ");
        scanf("%s", MDPDeCo);

        if (strcmp(identifiantDeCo, profil.identifiant) == 0 && strcmp(MDPDeCo, profil.MDP) == 0) {
            printf("Authentification réussie\n");
        } else {
            printf("Identifiant ou mot de passe incorrect\n");
        }
    }
}

// Fonction pour charger une partie
void chargerPartie(void) {
    // Implémenter la fonction pour charger une partie
}

// Fonction pour gérer le mot de passe
void motDePasse(void) {
    struct profil Configuration(void) {
        struct profil profil1;
        printf("Choisir votre identifiant : ");
        scanf("%s", profil1.identifiant);
        printf("Choisir votre mot de passe : ");
        scanf("%s", profil1.MDP);

        // Retourne la structure profil1
        return profil1;
    }
}

// Fonction pour afficher les scores
void scores(void) {
    // Implémenter la fonction pour afficher les scores
}