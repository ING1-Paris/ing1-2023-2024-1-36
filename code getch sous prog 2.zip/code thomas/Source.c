#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <conio.h>
#include "bibinoopy.h"

int Menu(void) {
    int choix;
    int retour;
    char matrice[LIGNE][COLONNE];
    struct profil joueur;
    printf("***********************************************\n");
    printf("****************** SNOOPY GAME ****************\n");
    printf("***********************************************\n");
    printf("1. REGLES DU JEU\n");
    printf("2. NOUVEAU JEU\n");
    printf("3. CHARGER UNE PARTIE\n");
    printf("4. CONFIGURATION IDENTIFIANT ET MOT DE PASSE\n");
    printf("5. SCORES\n");
    printf("6. QUITTER\n");
    printf("***********************************************\n");
    printf("***********************************************\n");

    choix = getch();

    switch (choix) {
        case '1':
            system("cls");
            reglesDuJeu();
            printf("retour : 1");
            scanf("%d", &retour);
            if (retour == 1) {
                Menu();
            }
            break;
        case '2':
            system("cls");
            connexion(joueur);
            system("cls");
            NIVEAU1(matrice);
            break;
        case '3':
            chargerPartie();
            nouveauJeu(joueur);
            break;
        case '4':
            system("cls");
            joueur = motDePasse();
            Menu();
            break;
        case '5':
            system("cls");
            break;
        case '6':
            system("cls");
            printf("Au revoir !\n");
            break;
        default:
            printf("Choix non valide\n");
            break;
    }

    return 0;
}


void reglesDuJeu(void) {
    printf("Le but de Snoopy est de récupérer 4 oiseaux aux 4 coins du niveau en un temps imparti. Le problème\n"
           "est que ces 4 oiseaux ne sont pas si faciles à récupérer. Une balle rebondit constamment dans le niveau\n"
           "afin de freiner Snoopy dans sa quête. Mais ce n'est pas tout, d'autres pièges sont présents comme des\n"
           "téléporteurs que la balle peut emprunter ou des cases piégées, voir même des blocs à pousser ou à\n"
           "casser...\n");
}

void nouveauJeu(struct profil joueur) {
    char matrice[LIGNE][COLONNE];
    // Appel de la fonction de connexion avec le profil du joueur
    int authentification = connexion(joueur);

    if (authentification) {
        printf("authentification réussie\n");
        affichage(matrice);
        NIVEAU1(matrice);
    } else {
        printf("Identifiant ou mot de passe incorrect\n");
    }
}

int connexion(struct profil joueur) {
    char identifiantDeCo[100];
    char MDPDeCo[100];
    int authentificationReussie = 0;

    do {
        printf("Identifiant : ");
        scanf("%s", identifiantDeCo);
        printf("Mot de passe : ");
        scanf("%s", MDPDeCo);

        if (strcmp(identifiantDeCo, joueur.identifiant) == 0 && strcmp(MDPDeCo, joueur.MDP) == 0) {
            authentificationReussie = 0;
        } else {
            authentificationReussie = 1;
        }
    } while (!authentificationReussie);

    return authentificationReussie;
}

struct profil motDePasse(void) {
    struct profil joueur = {"", "", ""};
    printf("Choisir votre identifiant : ");
    scanf("%s", joueur.identifiant);
    printf("Choisir votre mot de passe : ");
    scanf("%s", joueur.MDP);
    printf("Choisir un pseudo : ");
    scanf("%s", joueur.pseudo);
    system("cls");
    return joueur;
}

void chargerPartie(void) {
    int A;
    for (A = 120; A > 0; A = A - 1) {
        system("cls");
        printf("TIMER : %d", A);
        sleep(1);
    }
}

int scores(void) {
    return 0;
}

int INFOPARTIE(struct profil joueur) {


}

void affichermotrice(char motrice[LIGNE][COLONNE]){
    for (int i = 0; i < LIGNE; i++) {
        for (int j = 0; j < COLONNE; j++) {
            printf("%c", motrice[i][j]);
        }
        printf("\n");
    }
}

void affichage(char matrice[LIGNE][COLONNE]) {
    for (int i = 0; i < LIGNE; i++) {
        for (int j = 0; j < COLONNE; j++) {
            printf("%c", matrice[i][j]); // Affiche les bordures du tableau
        }
        printf("\n");  // Passer à la ligne suivante
    }
}
int seconds = TEMPS_JEU;
int x = 5, y = 10;
void timer(int *seconds) {
    if (*seconds > 0) {
        printf("\t\t\t\t\tTemps restant : %d secondes", *seconds);
        (*seconds)--;
        usleep(1000000);
        printf("\r"); // Retour au début de la ligne pour écraser le texte précédent
    }
}

