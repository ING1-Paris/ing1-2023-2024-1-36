#define LIGNE 10
#define COLONNE 20
#define TEMPS_JEU 120

#ifndef CODE_THOMAS_BIBINOOPY_H
#define CODE_THOMAS_BIBINOOPY_H

struct profil {
    char identifiant[100];
    char MDP[100];
    char pseudo[100];
};
void reglesDuJeu(void);
void nouveauJeu(struct profil);
void chargerPartie(void);
struct profil motDePasse(void);
void affichage(char matrice[LIGNE][COLONNE]);
void affichermotrice(char motrice[LIGNE][COLONNE]);
int INFOPARTIE(struct profil);
void reglesDuJeu(void);
void nouveauJeu(struct profil);
void chargerPartie(void);
struct profil motDePasse(void);
int scores(void);
int connexion(struct profil);
int Menu(void);
int NIVEAU1(char matrice[LIGNE][COLONNE]);
int NIVEAU2(char motrice[LIGNE][COLONNE]);
int  NIVEAU3(char matrice[LIGNE][COLONNE]);
int  NIVEAU4(char matrice[LIGNE][COLONNE]);
int jeu(int niv);
void affichermotrice(char motrice[LIGNE][COLONNE]);
void timer(int *seconds);

#endif //CODE_THOMAS_BIBINOOPY_H