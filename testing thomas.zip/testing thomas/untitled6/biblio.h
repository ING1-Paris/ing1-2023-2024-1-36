//
// Created by thoma on 28/11/2023.
//
const int ligne = 10;
const int colonne = 20;
const int TEMPS_JEU = 120;

#ifndef UNTITLED6_BIBLIO_H
#define UNTITLED6_BIBLIO_H
int JEU(char matrice[ligne][colonne]);
void reglesDuJeu(void);
void DebutEcran(void);
int INFOPARTIE(struct profil joueur);
void chargerPartie(void);
int connexion(struct profil joueur);

#endif //UNTITLED6_BIBLIO_H
