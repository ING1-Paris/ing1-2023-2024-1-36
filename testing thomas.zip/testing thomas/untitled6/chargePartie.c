//
// Created by thoma on 28/11/2023.
//
#include <stdio.h>
#include <unistd.h>

void chargerPartie(void) {
    int A;
    for (A = 120; A > 0; A = A - 1) {
        system("cls");
        printf("TIMER : %d", A);
        sleep(1);
    }
}