//
// Created by thoma on 28/11/2023.
//
#include <stdio.h>
const int ligne = 10;
const int colonne = 20;
const int TEMPS_JEU = 120;

void DebutEcran(void) {
    printf("***********************************************\n");
    printf("****************** SNOOPY GAME ****************\n");
    printf("***********************************************\n");
    printf("1. REGLES DU JEU\n");
    printf("2. NOUVEAU JEU\n");
    printf("3. CHARGER UNE PARTIE\n");
    printf("4. CONFIGURATION IDENTIFIANT ET MOT DE PASSE\n");
    printf("5. SCORES\n");
    printf("6. QUITTER\n");
    printf("***********************************************\n");
    printf("***********************************************\n");

}