//
// Created by thoma on 28/11/2023.
//
#include <stdio.h>
#include <string.h>
#include <unistd.h>
struct profil {
    char identifiant[100];
    char MDP[100];
    char pseudo[100];
};
int INFOPARTIE(struct profil joueur) {
    int Tempsfin;
    int A;
    int score;
    system("cls");

    for (A = 120; A > 0; A = A - 1) {
        system("cls");
        printf("TIMER : %d", A);
        sleep(1);
    }
    Tempsfin = A;
    score = Tempsfin * 100;
    printf("SCORE : %d", Tempsfin);
    return 0;
}