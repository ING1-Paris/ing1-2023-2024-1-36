//
// Created by thoma on 28/11/2023.
//

#include <stdio.h>
#include <string.h>

struct profil {
    char identifiant[100];
    char MDP[100];
    char pseudo[100];
};
struct profil motDePasse(void) {
    struct profil joueur = {"", "", ""};
    printf("Choisir votre identifiant : ");
    scanf("%s", joueur.identifiant);
    printf("Choisir votre mot de passe : ");
    scanf("%s", joueur.MDP);
    printf("Choisir un pseudo : ");
    scanf("%s", joueur.pseudo);
    return joueur;
}
int connexion(struct profil joueur) {
    char identifiantDeCo[100];
    char MDPDeCo[100];
    int authentificationReussie = 0;

    do {
        printf("Identifiant : ");
        scanf("%s", identifiantDeCo);
        printf("Mot de passe : ");
        scanf("%s", MDPDeCo);

        if (strcmp(identifiantDeCo, joueur.identifiant) == 0 && strcmp(MDPDeCo, joueur.MDP) == 0) {
            authentificationReussie = 0;
        } else {
            authentificationReussie = 1;
        }
    } while (!authentificationReussie);

    return authentificationReussie;
}