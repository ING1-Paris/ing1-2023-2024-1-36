#include <stdio.h>
#include <string.h>
#include "biblio.h"

struct profil {
    char identifiant[100];
    char MDP[100];
    char pseudo[100];
};

// Function Prototypes
void reglesDuJeu(void);
void nouveauJeu(struct profil);
void chargerPartie(void);
struct profil motDePasse(void);
int scores(void);
int Menu(void);
void affichage(char matrice[ligne][colonne]);
int JEU(char matrice[ligne][colonne]);

int main() {
    // Appel de la fonction Menu pour démarrer le programme
    Menu();

    return 0;
}

// Fonction pour afficher le menu et gérer les choix
int Menu(void) {
    int choix;
    int retour;
    struct profil joueur;
    DebutEcran();
    scanf("%d", &choix);

    switch (choix) {
        case 1:
            reglesDuJeu();
            printf("retour : 1");
            scanf("%d", &retour);
            if (retour == 1) {
                Menu();
            }
            break;
        case 2:
            nouveauJeu(joueur);
            break;
        case 3:
            chargerPartie();
            break;
        case 4:
            joueur = motDePasse();
            Menu();
            break;
        case 5:
            break;
        case 6:
            printf("Au revoir !\n");
            break;
        default:
            printf("Choix non valide\n");
            break;
    }

    return 0;
}
// Fonction pour commencer un nouveau jeu
void nouveauJeu(struct profil joueur) {
    char matrice[ligne][colonne];
    // Appel de la fonction de connexion avec le profil du joueur
    int authentification;

    if (authentification) {
        printf("authentification réussie\n");
        affichage(matrice);
        JEU(matrice);
    } else {
        printf("Identifiant ou mot de passe incorrect\n");
    }
}


