//
// Created by thoma on 08/11/2023.
//

#ifndef SNOOPY_BIBLIO_H
#define SNOOPY_BIBLIO_H
saisirTab(int lignes, int colonnes,char matrice[lignes][colonnes])
#endif //SNOOPY_BIBLIO_H
