#include <stdio.h>
#include <unistd.h>
#include <conio.h>
#include "bibinoopy.h"


int  NIVEAU4(char matrice[LIGNE][COLONNE]) {
    int seconds = TEMPS_JEU;
    int x=5, y=10;
    int NBRoiseau = 4;
    int NBRvie = 3;
    char noopy = 'S';
    char oiseau = 'O', blocpiege = 'P', blocfixe = '#';
    char balle = 'b';
    char blocpoussable1 = 'M';

    // Créer la matrice et remplir chaque élément avec un espace
    for (int i = 0; i < LIGNE; i++) {
        for (int j = 0; j < COLONNE; j++) {
            matrice[i][j] = ' ';
        }
    }
    int hauteurRectangle = 10;
    int largeurRectangle = 20;
    int ligneDebut = 0;
    int colonneDebut = 0;

    for (int i = ligneDebut; i < ligneDebut + hauteurRectangle; i++) {
        for (int j = colonneDebut; j < colonneDebut + largeurRectangle; j++) {
            if (i == ligneDebut || i == ligneDebut + hauteurRectangle - 1 || j == colonneDebut ||
                j == colonneDebut + largeurRectangle - 1) {
                matrice[i][j] = 35;  // Remplit uniquement les bords du rectangle
            }
        }
    }
    matrice[x][y] = noopy;
    matrice[1][1] = matrice[1][18] = matrice[8][18] = matrice[8][1] =oiseau;
    matrice[1][3]=matrice[8][3] = blocpiege;
    matrice[4][12]=matrice[4][17]=matrice[5][14]=matrice[5][16] = blocpoussable1;
    matrice[1][12]=matrice[2][1]=matrice[2][2]=matrice[2][3]=matrice[2][4]=matrice[2][5]=matrice[2][7]=matrice[2][8]=matrice[2][9]=matrice[2][10]=matrice[2][11]=matrice[2][14]=matrice[2][15]=matrice[2][16]=matrice[2][17]=matrice[2][18]=matrice[3][5]=matrice[3][7]=matrice[3][13]=matrice[3][14]=matrice[3][16]=matrice[3][18]=matrice[4][2]=matrice[4][3]=matrice[4][7]=matrice[4][9]=matrice[4][10]=matrice[4][11]=matrice[4][15]=matrice[5][2]= blocfixe;
    matrice[7][2]=matrice[8][15]=matrice[8][11]=matrice[8][12]=matrice[8][13]=matrice[8][10]=matrice[8][9]=matrice[8][8]=matrice[8][7]=matrice[7][18]=matrice[7][17]=matrice[7][14]=matrice[7][13]=matrice[7][7]=matrice[7][5]=matrice[7][4]=matrice[7][3]=matrice[7][1]=matrice[6][17]=matrice[6][15]=matrice[6][13]=matrice[6][9]=matrice[6][11]=matrice[6][7]=matrice[6][5]=matrice[5][18]=matrice[5][13]=matrice[5][11]=matrice[5][9]=matrice[5][3]= blocfixe;
    affichage(matrice);


    int touche;
    do {
        printf("Quel est votre direction ?\n"
               "z:Haut q:Gauche s:Bas d:Droite e:Fin\n");
        printf("%d VIE\n", NBRvie);
        printf("Niveau 4\n");
        do {
            touche = getch();
        } while (!(touche == 'q' || touche == 'z' || touche == 'd' || touche == 's' || touche == 'e' || touche == 'p'));
        system("cls");
        //séléction de la direction

        if (NBRvie == 0 || seconds == 0) {
            defaiteN4();
        }
        if (NBRoiseau == 0) {
            victoireN4();
        }

        switch (touche) {
            //Mouv GAUCHE
            case 'q': {
                if (matrice[x][y-1] == blocpiege){
                    NBRvie -= 1;
                    for ( int i = 0 ; i < 3 ; i++) {
                        system("cls");
                        printf("****************************************************\n");
                        printf("*********************** AIE !***********************\n");
                        printf("**************** CA DOIT FAIRE MAL !****************\n");
                        printf("****************IL TE RESTE %d VIE !****************\n", NBRvie);
                        printf("****************************************************\n");
                        sleep(1);
                    }
                    system("cls");
                    affichage(matrice);
                }
                if ((matrice[x][y - 1] == blocpoussable1) && (matrice[x][y - 2] == ' ')) {
                    matrice[x][y - 1] = ' ';  // Efface l'ancienne position du bloc poussable
                    matrice[x][y - 2] = blocpoussable1;  // Déplace le bloc poussable vers la nouvelle position
                }
                if(matrice[x][y - 1] == oiseau){
                    NBRoiseau -= 1;
                }
                //vérifiaction de la possibilité d'execution du mouvement en cas de bordure ou de bloc fixe
                if (matrice[x][y - 1] == blocfixe || matrice[x][y - 1] == matrice[ligneDebut][colonneDebut]) {
                    printf("Le mouvement n'est pas possible\n");
                    affichage(matrice);
                }
                    //déplacement permis si aucune autre condition n'est validé
                else {
                    printf("le mouvement est vers le haut\n");
                    //effacement de la position antèrieur
                    matrice[x][y] = ' ';
                    //déplacement vers le haut
                    matrice[x][y - 1] = noopy;
                    //incrémentation pour la valeur initale suivante
                    y--;
                    //affichage de la modification
                    affichage(matrice);
                }

                break;
            }
                //Mouv HAUT
            case 'z': {
                if (matrice[x-1][y] == blocpiege){
                    NBRvie -= 1;
                    for ( int i = 0 ; i < 3 ; i++) {
                        system("cls");
                        printf("****************************************************\n");
                        printf("*********************** AIE !***********************\n");
                        printf("**************** CA DOIT FAIRE MAL !****************\n");
                        printf("****************IL TE RESTE %d VIE !****************\n", NBRvie);
                        printf("****************************************************\n");
                        sleep(1);
                    }
                    system("cls");
                    affichage(matrice);
                }
                if ((matrice[x - 1][y] == blocpoussable1) && (matrice[x - 2][y]==' ')) {
                    matrice[x - 1][y] = ' ';  // Efface l'ancienne position du bloc poussable
                    matrice[x - 2][y] = blocpoussable1;  // Déplace le bloc poussable vers la nouvelle position
                }
                if(matrice[x-1][y] == oiseau){
                    NBRoiseau -= 1;
                }
                //vérifiaction de la possibilité d'execution du mouvement
                if (matrice[x - 1][y] == blocfixe || matrice[x - 1][y] == matrice[ligneDebut][colonneDebut]) {
                    printf("Le mouvement n'est pas possible\n");
                    affichage(matrice);
                }
                else {
                    printf("le mouvement est vers la gauche\n");
                    //effacement de la position antèrieur
                    matrice[x][y] = ' ';
                    //déplacement vers la gauche
                    matrice[x - 1][y] = noopy;
                    //incrémentation pour la valeur initale suivante
                    x--;
                    //affichage de la modification
                    affichage(matrice);
                }

                break;
            }
                //Mouv DROITE
            case 'd': {
                if (matrice[x][y+1] == blocpiege){
                    NBRvie -= 1;
                    for ( int i = 0 ; i < 3 ; i++) {
                        system("cls");
                        printf("****************************************************\n");
                        printf("*********************** AIE !***********************\n");
                        printf("**************** CA DOIT FAIRE MAL !****************\n");
                        printf("****************IL TE RESTE %d VIE !****************\n", NBRvie);
                        printf("****************************************************\n");
                        sleep(1);
                    }
                    system("cls");
                    affichage(matrice);
                }
                if ((matrice[x][y + 1] == blocpoussable1) && (matrice[x][y + 2]==' ')) {
                    matrice[x][y + 1] = ' ';  // Efface l'ancienne position du bloc poussable
                    matrice[x][y + 2] = blocpoussable1;  // Déplace le bloc poussable vers la nouvelle position
                }
                if(matrice[x][y + 1] == oiseau){
                    NBRoiseau -= 1;
                }
                //vérifiaction de la possibilité d'execution du mouvement
                if (matrice[x][y + 1] == blocfixe || matrice[x][y + 1] == matrice[ligneDebut][colonneDebut]) {
                    printf("Le mouvement n'est pas possible\n");
                    affichage(matrice);
                }
                else {
                    printf("le mouvement est vers le bas\n");
                    //effacement de la position antèrieur
                    matrice[x][y] = ' ';
                    //déplacement vers le bas
                    matrice[x][y + 1] = noopy;
                    //incrémentation pour la valeur initale suivante
                    y++;
                    //affichage de la modification
                    affichage(matrice);
                }

                break;
            }
                //Mouv BAS
            case 's': {
                if (matrice[x+1][y] == blocpiege){
                    NBRvie -= 1;
                    for ( int i = 0 ; i < 3 ; i++) {
                        system("cls");
                        printf("****************************************************\n");
                        printf("*********************** AIE !***********************\n");
                        printf("**************** CA DOIT FAIRE MAL !****************\n");
                        printf("****************IL TE RESTE %d VIE !****************\n", NBRvie);
                        printf("****************************************************\n");
                        sleep(1);
                    }
                    system("cls");
                    affichage(matrice);
                }
                if ((matrice[x+1][y] == blocpoussable1) && (matrice[x][y + 2]==' ')) {
                    matrice[x+1][y] = ' ';  // Efface l'ancienne position du bloc poussable
                    matrice[x+2][y] = blocpoussable1;  // Déplace le bloc poussable vers la nouvelle position
                }
                if (matrice[x + 1][y] == blocfixe || matrice[x + 1][y] == matrice[ligneDebut][colonneDebut]) {
                    printf("Le mouvement n'est pas possible\n");
                    affichage(matrice);
                }

                if(matrice[x+1][y] == oiseau){
                    NBRoiseau -= 1;
                }
                //vérifiaction de la possibilité d'execution du mouvement
                if (matrice[x + 1][y] == blocfixe || matrice[x + 1][y] == matrice[ligneDebut][colonneDebut]) {
                    printf("Le mouvement n'est pas possible\n");
                    affichage(matrice);
                }
                else
                {
                    printf("le mouvement est vers la droite\n");
                    //effacement de la position antèrieur
                    matrice[x][y] = ' ';
                    //déplacement vers le haut
                    matrice[x+1][y] = noopy;
                    //incrémentation pour la valeur initale suivante
                    x++;
                    //affichage de la modification
                    affichage(matrice);
                }

                break;
            }
        }
    }while(touche != 'e');
    return 0;
}
