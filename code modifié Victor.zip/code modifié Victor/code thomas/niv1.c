#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <conio.h>
#include "bibinoopy.h"
#define LIGNE 10
#define COLONNE 20
#define TEMPS_JEU 120

// Function Prototypes
int INFOPARTIE(struct profil);
void reglesDuJeu(void);
void nouveauJeu(struct profil);
void chargerPartie(void);
struct profil motDePasse(void);
int scores(void);
int connexion(struct profil);
int Menu(void);
void affichage(char matrice[LIGNE][COLONNE]);
int NIVEAU1(char matrice[LIGNE][COLONNE]);
int NIVEAU2(char motrice[LIGNE][COLONNE]);
int  NIVEAU3(char matrice[LIGNE][COLONNE]);
void affichermotrice(char motrice[LIGNE][COLONNE]);
void timer() {
    int seconds = 120; // Nombre de secondes du timer
    int score = seconds * 100;


    if(seconds >= 0){
        sleep(1); // Pause d'une seconde
        seconds--;

    }
    if (seconds == 0){
        printf("\t\t\t\t\tTemps écoulé!\n");
    }
}



int NIVEAU1(char matrice[LIGNE][COLONNE]) {
    int x=5, y=10;
    int NBRoiseau = 4;
    int NBRvie = 3;
    char noopy = 'S';
    char oiseau1 = 'O', oiseau2 = 'O', oiseau3 = 'O', oiseau4 = 'O', blocpiege1 = 'P', blocpiege2 = 'P', blocpiege3 = 'P', blocfixe = '#';
    char balle = 'b';
    char blocpoussable1='U';
    char blocpoussable2='U';
    char blocpoussable3='U';
    char touche;


    // Créer la matrice et remplir chaque élément avec un espace
    for (int i = 0; i < LIGNE; i++) {
        for (int j = 0; j < COLONNE; j++) {
            matrice[i][j] = ' ';
        }
    }
    int hauteurRectangle = 10;
    int largeurRectangle = 20;
    int ligneDebut = 0;
    int colonneDebut = 0;

    for (int i = ligneDebut; i < ligneDebut + hauteurRectangle; i++) {
        for (int j = colonneDebut; j < colonneDebut + largeurRectangle; j++) {
            if (i == ligneDebut || i == ligneDebut + hauteurRectangle - 1 || j == colonneDebut ||
                j == colonneDebut + largeurRectangle - 1) {
                matrice[i][j] = 35;  // Remplit uniquement les bords du rectangle
            }
        }
    }
    matrice[x][y] = noopy;
    matrice[1][1] = oiseau1;
    matrice[1][18] = oiseau2;
    matrice[8][18] = oiseau3;
    matrice[8][1] = oiseau4;
    matrice[4][12] = blocpiege1;
    matrice[7][3] = blocpiege2;
    matrice[3][9] = blocpiege3;
    matrice[6][12] = blocfixe;
    matrice[8][12] = blocpoussable1;
    matrice[4][3] = blocpoussable2;
    matrice[2][9] = blocpoussable3;
    int ballX = 2;
    int ballY = 2;
    matrice[ballX][ballY] = balle;
    affichage(matrice);

    do {

       if (_kbhit())
        {
            do
            {
                touche = getch();
            }while (!(touche == 'q' || touche == 'z' || touche == 'd' || touche == 's' || touche == 'e' || touche == 'p'));
            system("cls");
            //séléction de la direction

            if (NBRvie == 0 || TEMPS_JEU == 0) {
                defaiteN1();
            }
            if (NBRoiseau == 0) {
                victoireN1();
            }
            switch (touche) {
                //Mouv GAUCHE
                case 'q': {
                    if(matrice[x][y - 1] == oiseau1 || matrice[x][y - 1] == oiseau2 || matrice[x][y - 1] == oiseau3 || matrice[x][y - 1] == oiseau4){
                        NBRoiseau -= 1;
                    }
                    // Vérifier si la case à gauche du bloc poussable est vide
                    if (matrice[x][y - 1] == blocpoussable1) {
                        matrice[x][y - 1] = ' ';  // Efface l'ancienne position du bloc poussable
                        matrice[x][y - 2] = blocpoussable1;  // Déplace le bloc poussable vers la nouvelle position
                    }
                    //vérifiaction de la possibilité d'execution du mouvement en cas de bordure ou de bloc fixe
                    if (matrice[x][y - 1] == blocfixe || matrice[x][y - 1] == matrice[ligneDebut][colonneDebut]) {
                        printf("Le mouvement n'est pas possible\n");
                        affichage(matrice);
                    }
                        //déplacement permis si aucune autre condition n'est validé
                    else {
                        printf("le mouvement est vers le haut\n");
                        //effacement de la position antèrieur
                        matrice[x][y] = ' ';
                        //déplacement vers le haut
                        matrice[x][y - 1] = noopy;
                        //incrémentation pour la valeur initale suivante
                        y--;
                        //affichage de la modification
                        affichage(matrice);
                    }
                    if (matrice[x][y - 1] == blocpiege1 ||matrice[x][y - 1] == blocpiege2 || matrice[x][y - 1] == blocpiege3){
                        NBRvie -= 1;
                        for ( int i = 0 ; i < 3 ; i++) {
                            system("cls");
                            printf("****************************************************\n");
                            printf("*********************** AIE !***********************\n");
                            printf("**************** CA DOIT FAIRE MAL !****************\n");
                            printf("****************IL TE RESTE %d VIE !****************\n", NBRvie);
                            printf("****************************************************\n");
                            sleep(1);
                        }
                        affichage(matrice);
                    }
                    break;
                }
                    //Mouv HAUT
                case 'z': {
                    if(matrice[x - 1][y] == oiseau1 || matrice[x - 1][y] == oiseau2 || matrice[x - 1][y] == oiseau3 || matrice[x - 1][y] == oiseau4){
                        NBRoiseau -= 1;
                    }
                    if (matrice[x - 1][y] == blocpoussable1) {
                        matrice[x - 1][y] = ' ';  // Efface l'ancienne position du bloc poussable
                        matrice[x - 2][y] = blocpoussable1;  // Déplace le bloc poussable vers la nouvelle position
                    }
                    //vérifiaction de la possibilité d'execution du mouvement
                    if (matrice[x - 1][y] == blocfixe || matrice[x - 1][y] == matrice[ligneDebut][colonneDebut]) {
                        printf("Le mouvement n'est pas possible\n");
                        affichage(matrice);
                    }
                    else {
                        printf("le mouvement est vers la gauche\n");
                        //effacement de la position antèrieur
                        matrice[x][y] = ' ';
                        //déplacement vers la gauche
                        matrice[x - 1][y] = noopy;
                        //incrémentation pour la valeur initale suivante
                        x--;
                        //affichage de la modification
                        affichage(matrice);
                    }
                    if (matrice[x - 1][y] == blocpiege1 ||matrice[x - 1][y] == blocpiege2 || matrice[x - 1][y] == blocpiege3){
                        NBRvie -= 1;
                        for ( int i = 0 ; i < 3 ; i++) {
                            system("cls");
                            printf("****************************************************\n");
                            printf("*********************** AIE !***********************\n");
                            printf("**************** CA DOIT FAIRE MAL !****************\n");
                            printf("****************IL TE RESTE %d VIE !****************\n", NBRvie);
                            printf("****************************************************\n");
                            sleep(1);
                        }

                        affichage(matrice);
                    }
                    break;
                }
                    //Mouv DROITE
                case 'd': {
                    if(matrice[x][y + 1] == oiseau1 || matrice[x][y + 1] == oiseau2 || matrice[x][y + 1] == oiseau3 || matrice[x][y + 1] == oiseau4){
                        NBRoiseau -= 1;
                    }
                    if (matrice[x][y + 1] == blocpoussable1) {
                        matrice[x][y + 1] = ' ';  // Efface l'ancienne position du bloc poussable
                        matrice[x][y + 2] = blocpoussable1;  // Déplace le bloc poussable vers la nouvelle position
                    }
                    //vérifiaction de la possibilité d'execution du mouvement
                    if (matrice[x][y + 1] == blocfixe || matrice[x][y + 1] == matrice[ligneDebut][colonneDebut]) {
                        printf("Le mouvement n'est pas possible\n");
                        affichage(matrice);
                    }
                    else {
                        printf("le mouvement est vers le bas\n");
                        //effacement de la position antèrieur
                        matrice[x][y] = ' ';
                        //déplacement vers le bas
                        matrice[x][y + 1] = noopy;
                        //incrémentation pour la valeur initale suivante
                        y++;
                        //affichage de la modification
                        affichage(matrice);
                    }
                    if (matrice[x][y + 1] == blocpiege1 ||matrice[x][y + 1] == blocpiege2 || matrice[x][y + 1] == blocpiege3){
                        NBRvie -= 1;
                        for ( int i = 0 ; i < 3 ; i++) {
                            system("cls");
                            printf("****************************************************\n");
                            printf("*********************** AIE !***********************\n");
                            printf("**************** CA DOIT FAIRE MAL !****************\n");
                            printf("****************IL TE RESTE %d VIE !****************\n", NBRvie);
                            printf("****************************************************\n");
                            sleep(1);
                        }
                        affichage(matrice);
                    }
                    break;
                }
                    //Mouv BAS
                case 's': {
                    if (NBRvie == 0 || TEMPS_JEU == 0)
                    {
                        printf("****************************************************\n");
                        printf("******************* MECHANT NOOPY ! ****************\n");
                        printf("*******************   SALETE VA !   ****************\n");
                        printf("****************************************************\n\n");
                        printf("****************************************************\n");
                        printf("************** QUE VOULEZ VOUS FAIRE ? *************\n");
                        printf("****************************************************\n");
                        printf("1. RECOMMENCER\n");
                        printf("2. SCORES\n");
                        printf("3. RETOUR AU MENU\n");
                        printf("****************************************************\n");
                        int choix2;
                        choix2 = getch();
                        switch (choix2) {
                            case '1':
                                system("cls");
                                NIVEAU1(matrice);
                                break;
                            case '2':
                                system("cls");
                                break;
                            case '3':
                                system("cls");
                                Menu();
                                break;
                            default:
                                printf("Choix non valide\n");
                                break;
                        }
                    }
                    if (NBRoiseau == 0){
                        system("cls");
                        printf("****************************************************\n");
                        printf("*** BRAVO NOOPY TU AS ATTRAPE TOUS LES OISEAUX ! ***\n");
                        printf("********* TU ES UN BON LAPIN DE GARENNE ! **********\n");
                        printf("****************************************************\n\n");
                        printf("****************************************************\n");
                        printf("************* QUE VOULEZ VOUS FAIRE ? **************\n");
                        printf("1. PROCHAIN NIVEAU\n");
                        printf("2. REJOUER\n");
                        printf("3. NOUVEAU JEU\n");
                        printf("4. SCORES\n");
                        printf("5. RETOUR AU MENU\n");
                        printf("****************************************************\n");
                        printf("****************************************************\n");
                        int choix1;
                        choix1 = getch();
                        switch (choix1) {
                            case '1':
                                system("cls");
                                NIVEAU2(matrice);
                                break;
                            case '2':
                                system("cls");
                                NIVEAU1(matrice);
                                break;
                            case '3':
                                system("cls");
                                NIVEAU1(matrice);
                                break;
                            case '4':
                                system("cls");
                                break;
                            case '5':
                                system("cls");
                                Menu();
                                break;
                            default:
                                printf("Choix non valide\n");
                                break;
                        }
                    }
                    if(matrice[x + 1][y] == oiseau1 || matrice[x + 1][y] == oiseau2 || matrice[x + 1][y] == oiseau3 || matrice[x + 1][y] == oiseau4){
                        NBRoiseau -= 1;
                    }
                    if (matrice[x + 1][y] == blocpoussable1) {
                        matrice[x + 1][y] = ' ';  // Efface l'ancienne position du bloc poussable
                        matrice[x + 2][y] = blocpoussable1;  // Déplace le bloc poussable vers la nouvelle position
                    }
                    //vérifiaction de la possibilité d'execution du mouvement
                    if (matrice[x + 1][y] == blocfixe || matrice[x + 1][y] == matrice[ligneDebut][colonneDebut]) {
                        printf("Le mouvement n'est pas possible\n");
                        affichage(matrice);
                    }
                    else
                    {
                        printf("le mouvement est vers la droite\n");
                        //effacement de la position antèrieur
                        matrice[x][y] = ' ';
                        //déplacement vers le haut
                        matrice[x+1][y] = noopy;
                        //incrémentation pour la valeur initale suivante
                        x++;
                        //affichage de la modification
                        affichage(matrice);
                    }
                    if (matrice[x + 1][y] == blocpiege1 ||matrice[x + 1][y] == blocpiege2 || matrice[x + 1][y] == blocpiege3){
                        NBRvie -= 1;
                        for ( int i = 0 ; i < 3 ; i++) {
                            system("cls");
                            printf("****************************************************\n");
                            printf("*********************** AIE !***********************\n");
                            printf("**************** CA DOIT FAIRE MAL !****************\n");
                            printf("****************IL TE RESTE %d VIE !****************\n", NBRvie);
                            printf("****************************************************\n");
                            sleep(1);
                        }

                        affichage(matrice);
                    }
                    break;
                }
            }
        }
        timer();
    }
    while(touche != 'e');
    return 0;
}

