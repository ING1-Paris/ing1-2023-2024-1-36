//
// Created by jules on 04/12/2023.
//

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include "bibinoopy.h"


int NIVEAU2(char motrice[LIGNE][COLONNE]){
    int hauteurRectangle = 10;
    int largeurRectangle = 20;
    int ligneDebut = 0;
    int colonneDebut = 0;
    char blocpiege='P';
    int pourcentage=20;
    char blocpoussable1='U';
    char blocpoussable2='U';
    char blocpoussable3='U';


    // Initialisation de la motrice avec des murs
    for (int i = 0; i < LIGNE; i++) {
        for (int j = 0; j < COLONNE; j++) {
            motrice[i][j] = ' ';
        }
    }

    // Ajout de chemins aléatoires
    srand(time(NULL));

    for (int i = 2; i < LIGNE - 2; i++) {
        for (int j = 2; j < COLONNE - 2; j++) {
            if (rand() % 100 < pourcentage) {
                motrice[i][j] = blocpiege;
            }
        }
    }

    // Initialisation des murs extérieurs
    for (int i = 0; i < LIGNE; i++) {
        motrice[i][0] = '#';            // Mur gauche
        motrice[i][COLONNE - 1] = '#';  // Mur droit
    }

    for (int j = 0; j < COLONNE; j++) {
        motrice[0][j] = '#';            // Mur supérieur
        motrice[LIGNE - 1][j] = '#';   // Mur inférieur
    }

    int x = 5, y = 10;
    int NBRoiseau = 4;
    int NBRvie = 3;
    char noopy = 'S';
    char oiseau1 = 'O', oiseau2 = 'O', oiseau3 = 'O', oiseau4 = 'O', blocpiege1 = 'P', blocpiege2 = 'P', blocpiege3 = 'P', blocfixe = '#';
    char balle = 'b';

    motrice[x][y] = noopy;
    motrice[1][1] = oiseau1;
    motrice[1][18] = oiseau2;
    motrice[8][18] = oiseau3;
    motrice[8][1] = oiseau4;
    motrice[8][12] = blocpoussable1;
    motrice[4][3] = blocpoussable2;
    motrice[2][9] = blocpoussable3;

    int ballX = 2;
    int ballY = 2;
    motrice[ballX][ballY] = balle;
    affichermotrice(motrice);

    int touche;
    do {
        printf("Quel est votre direction ?\n"
               "z:Haut q:Gauche s:Bas d:Droite e:Fin\n");
        printf("Niveau 2\n");
        do {
            scanf("%c", &touche);
        } while (!(touche == 'q' || touche == 'z' || touche == 'd' || touche == 's' || touche == 'e' || touche == 'p'));
        system("cls");  // Note: Cette ligne pourrait nécessiter un ajustement selon le système d'exploitation

        // Sélection de la direction
        switch (touche) {
            // Mouv GAUCHE
            case 'q': {
                if (NBRvie == 0 || TEMPS_JEU == 0)
                {
                    printf("****************************************************\n");
                    printf("******************* MECHANT NOOPY ! ****************\n");
                    printf("*******************   SALETE VA !   ****************\n");
                    printf("****************************************************\n\n");
                    printf("****************************************************\n");
                    printf("************** QUE VOULEZ VOUS FAIRE ? *************\n");
                    printf("****************************************************\n");
                    printf("1. RECOMMENCER\n");
                    printf("2. SCORES\n");
                    printf("3. RETOUR AU MENU\n");
                    printf("****************************************************\n");
                    int choix2;
                    choix2 = getch();
                    switch (choix2) {
                        case '1':
                            system("cls");
                            NIVEAU2(motrice);
                            break;
                        case '2':
                            system("cls");
                            break;
                        case '3':
                            system("cls");
                            Menu();
                            break;
                        default:
                            printf("Choix non valide\n");
                            break;
                    }
                }
                if (NBRoiseau == 0){
                    system("cls");
                    printf("****************************************************\n");
                    printf("*** BRAVO NOOPY TU AS ATTRAPE TOUS LES OISEAUX ! ***\n");
                    printf("********* TU ES UN BON LAPIN DE GARENNE ! **********\n");
                    printf("****************************************************\n\n");
                    printf("****************************************************\n");
                    printf("************* QUE VOULEZ VOUS FAIRE ? **************\n");
                    printf("1. PROCHAIN NIVEAU\n");
                    printf("2. REJOUER\n");
                    printf("3. NOUVEAU JEU\n");
                    printf("4. SCORES\n");
                    printf("5. RETOUR AU MENU\n");
                    printf("****************************************************\n");
                    printf("****************************************************\n");
                    int choix1;
                    choix1 = getch();
                    switch (choix1) {
                        case '1':
                            system("cls");
                            NIVEAU3(motrice);
                            break;
                        case '2':
                            system("cls");
                            NIVEAU2(motrice);
                            break;
                        case '3':
                            system("cls");
                            NIVEAU1(motrice);
                            break;
                        case '4':
                            system("cls");
                            break;
                        case '5':
                            system("cls");
                            Menu();
                            break;
                        default:
                            printf("Choix non valide\n");
                            break;
                    }
                }
                if(motrice[x][y - 1] == oiseau1 || motrice[x][y - 1] == oiseau2 || motrice[x][y - 1] == oiseau3 || motrice[x][y - 1] == oiseau4){
                    NBRoiseau -= 1;
                }
                if (motrice[x][y - 1] == blocpoussable1) {
                    motrice[x][y - 1] = ' ';  // Efface l'ancienne position du bloc poussable
                    motrice[x][y - 2] = blocpoussable1;  // Déplace le bloc poussable vers la nouvelle position
                }
                //vérifiaction de la possibilité d'execution du mouvement en cas de bordure ou de bloc fixe
                if (motrice[x][y - 1] == blocfixe || motrice[x][y - 1] == motrice[ligneDebut][colonneDebut]) {
                    printf("Le mouvement n'est pas possible\n");
                    affichermotrice(motrice);
                }
                    //déplacement permis si aucune autre condition n'est validé
                else {
                    printf("le mouvement est vers le haut\n");
                    //effacement de la position antèrieur
                    motrice[x][y] = ' ';
                    //déplacement vers le haut
                    motrice[x][y - 1] = noopy;
                    //incrémentation pour la valeur initale suivante
                    y--;
                    //affichermotrice de la modification
                    affichermotrice(motrice);
                }
                if (motrice[x][y - 1] == blocpiege1 ||motrice[x][y - 1] == blocpiege2 || motrice[x][y - 1] == blocpiege3){
                    NBRvie -= 1;
                    for ( int i = 0 ; i < 3 ; i++) {
                        system("cls");
                        printf("****************************************************\n");
                        printf("*********************** AIE !***********************\n");
                        printf("**************** CA DOIT FAIRE MAL !****************\n");
                        printf("****************IL TE RESTE %d VIE !****************\n", NBRvie);
                        printf("****************************************************\n");
                        sleep(1);
                    }
                    affichermotrice(motrice);
                }
                // Logique du mouvement vers la gauche
                // ...
                break;
            }
                // Mouv HAUT
            case 'z': {

                if (NBRvie == 0 || TEMPS_JEU == 0)
                {
                    printf("****************************************************\n");
                    printf("******************* MECHANT NOOPY ! ****************\n");
                    printf("*******************   SALETE VA !   ****************\n");
                    printf("****************************************************\n\n");
                    printf("****************************************************\n");
                    printf("************** QUE VOULEZ VOUS FAIRE ? *************\n");
                    printf("****************************************************\n");
                    printf("1. RECOMMENCER\n");
                    printf("2. SCORES\n");
                    printf("3. RETOUR AU MENU\n");
                    printf("****************************************************\n");
                    int choix2;
                    choix2 = getch();
                    switch (choix2) {
                        case '1':
                            system("cls");
                            NIVEAU2(motrice);
                            break;
                        case '2':
                            system("cls");
                            break;
                        case '3':
                            system("cls");
                            Menu();
                            break;
                        default:
                            printf("Choix non valide\n");
                            break;
                    }
                }
                if (NBRoiseau == 0){
                    system("cls");
                    printf("****************************************************\n");
                    printf("*** BRAVO NOOPY TU AS ATTRAPE TOUS LES OISEAUX ! ***\n");
                    printf("********* TU ES UN BON LAPIN DE GARENNE ! **********\n");
                    printf("****************************************************\n\n");
                    printf("****************************************************\n");
                    printf("************* QUE VOULEZ VOUS FAIRE ? **************\n");
                    printf("1. PROCHAIN NIVEAU\n");
                    printf("2. REJOUER\n");
                    printf("3. NOUVEAU JEU\n");
                    printf("4. SCORES\n");
                    printf("5. RETOUR AU MENU\n");
                    printf("****************************************************\n");
                    printf("****************************************************\n");
                    int choix1;
                    choix1 = getch();
                    switch (choix1) {
                        case '1':
                            system("cls");
                            NIVEAU3(motrice);
                            break;
                        case '2':
                            system("cls");
                            NIVEAU2(motrice);
                            break;
                        case '3':
                            system("cls");
                            NIVEAU1(motrice);
                            break;
                        case '4':
                            system("cls");
                            break;
                        case '5':
                            system("cls");
                            Menu();
                            break;
                        default:
                            printf("Choix non valide\n");
                            break;
                    }
                }
                if(motrice[x - 1][y] == oiseau1 || motrice[x - 1][y] == oiseau2 || motrice[x - 1][y] == oiseau3 || motrice[x - 1][y] == oiseau4){
                    NBRoiseau -= 1;
                }
                if (motrice[x - 1][y] == blocpoussable1) {
                    motrice[x - 1][y] = ' ';  // Efface l'ancienne position du bloc poussable
                    motrice[x - 2][y] = blocpoussable1;  // Déplace le bloc poussable vers la nouvelle position
                }
                //vérifiaction de la possibilité d'execution du mouvement
                if (motrice[x - 1][y] == blocfixe || motrice[x - 1][y] == motrice[ligneDebut][colonneDebut]) {
                    printf("Le mouvement n'est pas possible\n");
                    affichermotrice(motrice);
                }
                else {
                    printf("le mouvement est vers la gauche\n");
                    //effacement de la position antèrieur
                    motrice[x][y] = ' ';
                    //déplacement vers la gauche
                    motrice[x - 1][y] = noopy;
                    //incrémentation pour la valeur initale suivante
                    x--;
                    //affichermotrice de la modification
                    affichermotrice(motrice);
                }
                if (motrice[x - 1][y] == blocpiege1 ||motrice[x - 1][y] == blocpiege2 || motrice[x - 1][y] == blocpiege3){
                    NBRvie -= 1;
                    for ( int i = 0 ; i < 3 ; i++) {
                        system("cls");
                        printf("****************************************************\n");
                        printf("*********************** AIE !***********************\n");
                        printf("**************** CA DOIT FAIRE MAL !****************\n");
                        printf("****************IL TE RESTE %d VIE !****************\n", NBRvie);
                        printf("****************************************************\n");
                        sleep(1);
                    }

                    affichermotrice(motrice);
                }
                // Logique du mouvement vers le haut
                // ...
                break;
            }
                // Mouv DROITE
            case 'd':
            {
                if (NBRvie == 0 || TEMPS_JEU == 0)
                {
                    printf("****************************************************\n");
                    printf("******************* MECHANT NOOPY ! ****************\n");
                    printf("*******************   SALETE VA !   ****************\n");
                    printf("****************************************************\n\n");
                    printf("****************************************************\n");
                    printf("************** QUE VOULEZ VOUS FAIRE ? *************\n");
                    printf("****************************************************\n");
                    printf("1. RECOMMENCER\n");
                    printf("2. SCORES\n");
                    printf("3. RETOUR AU MENU\n");
                    printf("****************************************************\n");
                    int choix2;
                    choix2 = getch();
                    switch (choix2) {
                        case '1':
                            system("cls");
                            NIVEAU2(motrice);
                            break;
                        case '2':
                            system("cls");
                            break;
                        case '3':
                            system("cls");
                            Menu();
                            break;
                        default:
                            printf("Choix non valide\n");
                            break;
                    }
                }
                if (NBRoiseau == 0){
                    system("cls");
                    printf("****************************************************\n");
                    printf("*** BRAVO NOOPY TU AS ATTRAPE TOUS LES OISEAUX ! ***\n");
                    printf("********* TU ES UN BON LAPIN DE GARENNE ! **********\n");
                    printf("****************************************************\n\n");
                    printf("****************************************************\n");
                    printf("************* QUE VOULEZ VOUS FAIRE ? **************\n");
                    printf("1. PROCHAIN NIVEAU\n");
                    printf("2. REJOUER\n");
                    printf("3. NOUVEAU JEU\n");
                    printf("4. SCORES\n");
                    printf("5. RETOUR AU MENU\n");
                    printf("****************************************************\n");
                    printf("****************************************************\n");
                    int choix1;
                    choix1 = getch();
                    switch (choix1) {
                        case '1':
                            system("cls");
                            NIVEAU3(motrice);
                            break;
                        case '2':
                            system("cls");
                            NIVEAU2(motrice);
                            break;
                        case '3':
                            system("cls");
                            NIVEAU1(motrice);
                            break;
                        case '4':
                            system("cls");
                            break;
                        case '5':
                            system("cls");
                            Menu();
                            break;
                        default:
                            printf("Choix non valide\n");
                            break;
                    }
                }
                if(motrice[x][y + 1] == oiseau1 || motrice[x][y + 1] == oiseau2 || motrice[x][y + 1] == oiseau3 || motrice[x][y + 1] == oiseau4){
                    NBRoiseau -= 1;
                }
                if (motrice[x][y + 1] == blocpoussable1) {
                    motrice[x][y + 1] = ' ';  // Efface l'ancienne position du bloc poussable
                    motrice[x][y + 2] = blocpoussable1;  // Déplace le bloc poussable vers la nouvelle position
                }
                //vérifiaction de la possibilité d'execution du mouvement
                if (motrice[x][y + 1] == blocfixe || motrice[x][y + 1] == motrice[ligneDebut][colonneDebut]) {
                    printf("Le mouvement n'est pas possible\n");
                    affichermotrice(motrice);
                }
                else {
                    printf("le mouvement est vers le bas\n");
                    //effacement de la position antèrieur
                    motrice[x][y] = ' ';
                    //déplacement vers le bas
                    motrice[x][y + 1] = noopy;
                    //incrémentation pour la valeur initale suivante
                    y++;
                    //affichermotrice de la modification
                    affichermotrice(motrice);
                }
                if (motrice[x][y + 1] == blocpiege1 ||motrice[x][y + 1] == blocpiege2 || motrice[x][y + 1] == blocpiege3){
                    NBRvie -= 1;
                    for ( int i = 0 ; i < 3 ; i++) {
                        system("cls");
                        printf("****************************************************\n");
                        printf("*********************** AIE !***********************\n");
                        printf("**************** CA DOIT FAIRE MAL !****************\n");
                        printf("****************IL TE RESTE %d VIE !****************\n", NBRvie);
                        printf("****************************************************\n");
                        sleep(1);
                    }
                    affichermotrice(motrice);
                }
                // Logique du mouvement vers la droite
                // ...
                break;
            }
                // Mouv BAS
            case 's': {
                if (NBRvie == 0 || TEMPS_JEU == 0)
                {
                    printf("****************************************************\n");
                    printf("******************* MECHANT NOOPY ! ****************\n");
                    printf("*******************   SALETE VA !   ****************\n");
                    printf("****************************************************\n\n");
                    printf("****************************************************\n");
                    printf("************** QUE VOULEZ VOUS FAIRE ? *************\n");
                    printf("****************************************************\n");
                    printf("1. RECOMMENCER\n");
                    printf("2. SCORES\n");
                    printf("3. RETOUR AU MENU\n");
                    printf("****************************************************\n");
                    int choix2;
                    choix2 = getch();
                    switch (choix2) {
                        case '1':
                            system("cls");
                            NIVEAU2(motrice);
                            break;
                        case '2':
                            system("cls");
                            break;
                        case '3':
                            system("cls");
                            Menu();
                            break;
                        default:
                            printf("Choix non valide\n");
                            break;
                    }
                }
                if (NBRoiseau == 0){
                    system("cls");
                    printf("****************************************************\n");
                    printf("*** BRAVO NOOPY TU AS ATTRAPE TOUS LES OISEAUX ! ***\n");
                    printf("********* TU ES UN BON LAPIN DE GARENNE ! **********\n");
                    printf("****************************************************\n\n");
                    printf("****************************************************\n");
                    printf("************* QUE VOULEZ VOUS FAIRE ? **************\n");
                    printf("1. PROCHAIN NIVEAU\n");
                    printf("2. REJOUER\n");
                    printf("3. NOUVEAU JEU\n");
                    printf("4. SCORES\n");
                    printf("5. RETOUR AU MENU\n");
                    printf("****************************************************\n");
                    printf("****************************************************\n");
                    int choix1;
                    choix1 = getch();
                    switch (choix1) {
                        case '1':
                            system("cls");
                            NIVEAU3(motrice);
                            break;
                        case '2':
                            system("cls");
                            NIVEAU2(motrice);
                            break;
                        case '3':
                            system("cls");
                            NIVEAU1(motrice);
                            break;
                        case '4':
                            system("cls");
                            break;
                        case '5':
                            system("cls");
                            Menu();
                            break;
                        default:
                            printf("Choix non valide\n");
                            break;
                    }
                }
                if(motrice[x + 1][y] == oiseau1 || motrice[x + 1][y] == oiseau2 || motrice[x + 1][y] == oiseau3 || motrice[x + 1][y] == oiseau4){
                    NBRoiseau -= 1;
                }
                if (motrice[x + 1][y] == blocpoussable1) {
                    motrice[x + 1][y] = ' ';  // Efface l'ancienne position du bloc poussable
                    motrice[x + 2][y] = blocpoussable1;  // Déplace le bloc poussable vers la nouvelle position
                }
                //vérifiaction de la possibilité d'execution du mouvement
                if (motrice[x + 1][y] == blocfixe || motrice[x + 1][y] == motrice[ligneDebut][colonneDebut]) {
                    printf("Le mouvement n'est pas possible\n");
                    affichermotrice(motrice);
                }
                else
                {
                    printf("le mouvement est vers la droite\n");
                    //effacement de la position antèrieur
                    motrice[x][y] = ' ';
                    //déplacement vers le haut
                    motrice[x+1][y] = noopy;
                    //incrémentation pour la valeur initale suivante
                    x++;
                    //affichermotrice de la modification
                    affichermotrice(motrice);
                }
                if (motrice[x + 1][y] == blocpiege1 ||motrice[x + 1][y] == blocpiege2 || motrice[x + 1][y] == blocpiege3){
                    NBRvie -= 1;
                    for ( int i = 0 ; i < 3 ; i++) {
                        system("cls");
                        printf("****************************************************\n");
                        printf("*********************** AIE !***********************\n");
                        printf("**************** CA DOIT FAIRE MAL !****************\n");
                        printf("****************IL TE RESTE %d VIE !****************\n", NBRvie);
                        printf("****************************************************\n");
                        sleep(1);
                    }

                    affichermotrice(motrice);
                }
                // Logique du mouvement vers le bas
                // ...
                break;
            }
        }
    } while (touche != 'e');

    return 0;
}
