//
// Created by thoma on 30/11/2023.
//
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windows.h>
#include "menu.h"
#include "regle.h"
#include "partie.h"
#include "motdepasse.h"
#include "score.h"
#include "charger.h"

#define NIV1 1
#define MENU_PRINCIPAL 3
int etatJeu = NIV1;

int score = 0;
int gameOver = 0;
int vie = 3;
int niveau = 0;
double remaining_time;
char tableau[20][75];

struct Snoopy {
    int x;    // Position x de Snoopy
    int y;    // Position y de Snoopy
} snoopy;

struct Oiseau {
    int x; // Position x de l'oiseau
    int y; // Position y de l'oiseau
} oiseaux[4];

struct Ennemi {
    int x; // Position x de l'ennemi
    int y; // Position y de l'ennemi
    int dx; // Direction x de l'ennemi
    int dy; // Direction y de l'ennemi
} ennemis[1];

struct Caisse {
    int x; // Position x de la caisse
    int y; // Position y de la caisse
    bool dejaDeplace;
} caisses[12];

int nombreOiseaux = 4;
int nombreEnnemis = 1;
int nombreCaisses = 12;

void sauvegarderPartie(char *nom, int score1, int vie1, struct Snoopy snoopy, struct Oiseau oiseaux[], int nombreOiseaux, struct Ennemi ennemis[], int nombreEnnemis, struct Caisse caisses[], int nombreCaisses, double remaining_time, char tableau[20][75]) {
    FILE *file;
    char filename[20];
    sprintf(filename, "sauvegarde%s.txt", nom); // Créer le nom du fichier avec le nom de sauvegarde
    file = fopen(filename, "w");
    if (file == NULL) {
        printf("Impossible d'ouvrir le fichier de sauvegarde.\n");
        return;
    }
    // Écrire les données de jeu dans le fichier
    fprintf(file, "\t\t\t\t\t   ************************************\n");
    fprintf(file, "\t\t\t\t\t   *\t         NIVEAU %d             *\n", niveau);
    fprintf(file, "\t\t\t\t\t   ************************************\n\n");
    fprintf(file, "\t\t\t\t\t\t\t Score: %d\n", score1);
    fprintf(file, "\t\t\t\t\t\t\t    %d ♥\n", vie1);
    fprintf(file, "\t\t\t\t\t        Temps restant: %.0f secondes\n\n", remaining_time);
    for (int i = 0; i < 20; i++) {
        for (int j = 0; j < 73; j++) {
            fprintf(file, "%c", tableau[i][j]);
        }
        fprintf(file, "\n");
    }
    fprintf(file, "Position x de Snoopy: %d\n", snoopy.x);
    fprintf(file, "Position y de Snoopy: %d\n", snoopy.y);
    for (int i = 0; i < nombreOiseaux; i++) {
        fprintf(file, "Position x de l'oiseau %d: %d\n", i+1, oiseaux[i].x);
        fprintf(file, "Position y de l'oiseau %d: %d\n", i+1, oiseaux[i].y);
    }
    for (int i = 0; i < nombreCaisses; i++) {
        fprintf(file, "Position x de la caisse %d: %d\n", i+1, caisses[i].x);
        fprintf(file, "Position y de la caisse %d: %d\n", i+1, caisses[i].y);
    }
    for (int i = 0; i < nombreEnnemis; i++) {
        fprintf(file, "Position x de l'ennemi %d: %d\n", i+1, ennemis[i].x);
        fprintf(file, "Position y de l'ennemi %d: %d\n", i+1, ennemis[i].y);
    }
    fclose(file);
    printf("Partie sauvegardée avec succès.\n");
}


void Niv1(int *score, int *vie) {
    time_t start_time = time(NULL);
    srand(time(NULL)); // Initialiser la graine pour la génération de nombres aléatoires
    bool enPause = false;
    system("cls");
    // Initialisation de Snoopy
    struct Snoopy snoopy = {60, 7, 3, 0};

    // Initialisation des oiseaux
    struct Oiseau oiseaux[4] = {{50, 2},
                                {70, 2},
                                {50, 12},
                                {70, 12}};
    int nombreOiseaux = 4;

    // Initialisation des ennemis
    struct Ennemi ennemis[1] = {{rand() % 21 + 50, rand() % 11 + 2, 1, 1}};
    int nombreEnnemis = 1;

    // Initialisation des caisses
    struct Caisse caisses[12] = {
            {57, 6, false},
            {58, 5, false},
            {59, 4, false},
            {61, 4, false},
            {62, 5, false},
            {63, 6, false},
            {63, 8, false},
            {62, 9, false},
            {61, 10, false},
            {59, 10, false},
            {58, 9, false},
            {57, 8, false}
    };
    int nombreCaisses = 12;

    if (ennemis[0].x == 60 && ennemis[0].y == 7) {
        system("cls");
        ennemis[0].x = rand() % 21 + 50; // Entre 50 et 70
        ennemis[0].y = rand() % 11 + 2; // Entre 2 et 12  // Entre 8 et 18
    }
    if (ennemis[0].x == 50 && ennemis[0].y == 2) {
        system("cls");
        ennemis[0].x = rand() % 21 + 50; // Entre 50 et 70
        ennemis[0].y = rand() % 11 + 2; // Entre 2 et 12  // Entre 8 et 18
    }
    if (ennemis[0].x == 70 && ennemis[0].y == 2) {
        system("cls");
        ennemis[0].x = rand() % 21 + 50; // Entre 50 et 70
        ennemis[0].y = rand() % 11 + 2; // Entre 2 et 12  // Entre 8 et 18
    }
    if (ennemis[0].x == 50 && ennemis[0].y == 12) {
        system("cls");
        ennemis[0].x = rand() % 21 + 50; // Entre 50 et 70
        ennemis[0].y = rand() % 11 + 2; // Entre 2 et 12  // Entre 8 et 18
    }
    if (ennemis[0].x == 70 && ennemis[0].y == 12) {
        system("cls");
        ennemis[0].x = rand() % 21 + 50; // Entre 50 et 70
        ennemis[0].y = rand() % 11 + 2; // Entre 2 et 12  // Entre 8 et 18
    }
    time_t start_time_enemy = time(NULL);

    char tableau[20][75]; // Déclaration d'un tableau de 20 lignes et 10 colonnes
    for (int ligne = 0; ligne < 20; ligne++) {
        for (int colonne = 0; colonne < 75; colonne++) {
            if ((colonne == 49 || colonne == 71) && (ligne < 14 || ligne > 19) && (ligne < 0 || ligne > 0)) {
                tableau[ligne][colonne] = '|';
            } else if ((ligne == 1 || ligne == 13) && (colonne < 0 || colonne > 47)) {
                tableau[ligne][colonne] = '-';
            } else {
                tableau[ligne][colonne] = ' ';
            }
        }
    }

    int nbroiseaux = 0;
    while (1) {
        // Affichage du tableau avec les éléments initialisés
        printf("█ █\t\t\t\t\t   ************************************\n");
        printf("█ █\t\t\t\t\t   *\t         NIVEAU 1             *\n");
        printf("\t\t\t\t\t   ************************************\n\n");
        printf("\t\t\t\t\t\t\t Score: %d\n", *score);
        printf("\t\t\t\t\t\t\t    %d ♥\n", *vie);

        time_t current_time = time(NULL);
        double time_elapsed_in_seconds = difftime(current_time, start_time);
        double remaining_time = 120.0 - time_elapsed_in_seconds;
        printf("\t\t\t\t\t        Temps restant : %.0f secondes\n\n", remaining_time);

        if (time_elapsed_in_seconds >= 120.0) {
            system("cls");
            Sleep(500);
            printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\t       GAME OVER");

            printf("(\n\n\n");
            printf("                                                       Score: %d", *score);
            printf("\tVie: %d ♥", *vie);
            Sleep(3000);
            return;
        }

        for (int ligne = 0; ligne < 20; ligne++) {
            for (int colonne = 0; colonne < 73; colonne++) {
                int caisseTrouvee = 0;
                for (int i = 0; i < nombreCaisses; i++) {
                    if (caisses[i].x == colonne && caisses[i].y == ligne) {
                        afficher_caisse_bleu();
                        caisseTrouvee = 1;
                        break;
                    }
                }
                if (caisseTrouvee) continue;
                if (snoopy.x == colonne && snoopy.y == ligne) {
                    snoopy_blanc();
                } else if (oiseaux[0].x == colonne && oiseaux[0].y == ligne) {
                    afficher_oiseau_vert();
                } else if (oiseaux[1].x == colonne && oiseaux[1].y == ligne) {
                    afficher_oiseau_vert();
                } else if (oiseaux[2].x == colonne && oiseaux[2].y == ligne) {
                    afficher_oiseau_vert();
                } else if (oiseaux[3].x == colonne && oiseaux[3].y == ligne) {
                    afficher_oiseau_vert();
                } else if (ennemis[0].x == colonne && ennemis[0].y == ligne) {
                    afficher_balle_rouge();
                } else {
                    printf("%c", tableau[ligne][colonne]);
                }
            }
            printf("\n");
        }

        double time_elapsed_in_seconds_enemy = difftime(current_time, start_time_enemy);

        if (time_elapsed_in_seconds_enemy >= 1.0) {
            ennemis[0].x += ennemis[0].dx;
            ennemis[0].y += ennemis[0].dy;
            start_time_enemy = time(NULL); // Réinitialisez le temps de départ après que l'ennemi a bougé
        }

        // Vérifier les collisions avec les murs
        if (ennemis[0].x < 51) {
            ennemis[0].dx *= -1; // Rebondir horizontalement
            ennemis[0].x = 51; // Replacer l'ennemi à l'intérieur des limites
        } else if (ennemis[0].x > 69) {
            ennemis[0].dx *= -1; // Rebondir horizontalement
            ennemis[0].x = 69; // Replacer l'ennemi à l'intérieur des limites
        }

        if (ennemis[0].y < 2) {
            ennemis[0].dy *= -1; // Rebondir verticalement
            ennemis[0].y = 2; // Replacer l'ennemi à l'intérieur des limites
        } else if (ennemis[0].y > 12) {
            ennemis[0].dy *= -1; // Rebondir verticalement
            ennemis[0].y = 12; // Replacer l'ennemi à l'intérieur des limites
        }

        for (int i = 0; i < nombreOiseaux; i++) {
            if (snoopy.x == oiseaux[i].x && snoopy.y == oiseaux[i].y) {
                nbroiseaux = nbroiseaux + 1;
                oiseaux[i].x = -1;
                oiseaux[i].y = -1;
            }
        }

        if (nbroiseaux == 4) {
            niveau = 1;
            double remaining_time = 120.0 - time_elapsed_in_seconds;
            int scoreNiveau = remaining_time * 100;
            *score += scoreNiveau;
            system("cls");
            printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\tBRAVO TU AS REUSSI LE NIVEAU 1");

            printf("!\n\n\n\n");
            printf("\t\t\t\t\t\tScore final: %d\n", *score);
            Sleep(1500);
            return;
        }

        if (snoopy.x == ennemis[0].x && snoopy.y == ennemis[0].y) {
            *score = 0;
            nbroiseaux = 0;
            *vie -= 1;
            snoopy.x = 60;
            snoopy.y = 7;
            oiseaux[0].x = 50;
            oiseaux[0].y = 2;
            oiseaux[1].x = 70;
            oiseaux[1].y = 2;
            oiseaux[2].x = 50;
            oiseaux[2].y = 12;
            oiseaux[3].x = 70;
            oiseaux[3].y = 12;
            do {
                ennemis[0].x = rand() % 21 + 50; // Position aléatoire entre 50 et 70
                ennemis[0].y = rand() % 11 + 2; // Entre 2 et 12  // Position aléatoire entre 8 et 18
            } while (snoopy.x == ennemis[0].x && snoopy.y == ennemis[0].y);
        }

        if (*vie == 0) {
            system("cls");
            Sleep(500);
            printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\t       GAME OVER");

            printf("                                                       Score: %d", *score);
            printf("\tVie: %d ♥", *vie);
            Sleep(3000);
            gameOver = 1; // Game over
        }
        if (gameOver == 1) {
            break;
        }
        int touche = getch(); // Lire une touche du clavier
        // Si 'p' est pressé, afficher le menu de pause
        if (touche == 27) {
            time_t pause_time = time(NULL);
            enPause = true; // Mettre le jeu en pause
            int choix = 1;
            while (1) {
                system("cls");
                printf("\t\t\t\t\t   ************************************\n");
                printf("\t\t\t\t\t   *\t        MENU PAUSE            *\n");
                printf("\t\t\t\t\t   ************************************\n\n");
                printf("\t\t\t\t\t   ● Sauvegarder la partie %s\n", choix == 1 ? "►" : "");
                printf("\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t   ● Retour au menu %s\n", choix == 2 ? "►" : "");

                char key = getch();
                if ((key == 's' || key == 'd') && choix < 2) { // 's' pour aller en bas
                    choix++;
                } else if ((key == 'z' || key == 'q') && choix > 1) { // 'z' pour aller en haut
                    choix--;
                } else if (key == 27) { // Touche Entrée
                    system("cls");
                    break;
                } else if (key == 13) { // Touche Entrée
                    if (choix == 1) {
                        system("cls");
                        char nom[100];
                        printf("\t\t\t\t\t   ************************************\n");
                        printf("\t\t\t\t\t   *\t        SAUVEGARDE            *\n");
                        printf("\t\t\t\t\t   ************************************\n\n");
                        printf("\t\t\t\t\t   ● Nom de la sauvegarde: ");
                        scanf("%s", nom);
                        sauvegarderPartie(nom, *score, *vie, snoopy, oiseaux, nombreOiseaux, ennemis, nombreEnnemis, caisses, nombreCaisses, remaining_time, tableau);
                    } else if (choix == 2) {
                        system("cls");
                        // Retour au menu principal
                        etatJeu = MENU_PRINCIPAL;
                        return;
                    }
                }
            }

            time_t resume_time = time(NULL); // Enregistrer le temps de fin de pause
            double pause_duration = difftime(resume_time, pause_time); // Calculer la durée de la pause

            // Ajuster le temps de départ pour tenir compte de la durée de la pause
            start_time += pause_duration;

            enPause = false; // Reprendre le jeu

        }

        // Gérer les déplacements en fonction de la touche
        if (!enPause) {
            switch (touche) {
                case 'z':
                case 'Z':
                    system("cls");
                    // Vérifier si une caisse se trouve au-dessus de Snoopy
                    bool canMove = true;
                    for (int i = 0; i < nombreCaisses; i++) {
                        if (caisses[i].x == snoopy.x && caisses[i].y == snoopy.y - 1) {
                            // Vérifier si l'espace au-dessus de la caisse est vide et dans les limites du tableau
                            bool canMoveCaisse = true;
                            for (int j = 0; j < nombreCaisses; j++) {
                                if (caisses[j].x == caisses[i].x && caisses[j].y == caisses[i].y - 1) {
                                    canMoveCaisse = false; // Ne pas déplacer la caisse
                                    break;
                                }
                            }
                            if (canMoveCaisse && caisses[i].y - 1 >= 2 && !caisses[i].dejaDeplace) { // Ajout de la vérification de dejaDeplace
                                // Déplacer la caisse vers le haut
                                caisses[i].y--;
                                caisses[i].dejaDeplace = true; // Marquer la caisse comme déjà déplacée
                            } else {
                                canMove = false; // Ne pas déplacer Snoopy si la caisse ne peut pas être déplacée
                            }
                        }
                    }
                    // Déplacer le joueur vers le haut
                    if (canMove && snoopy.y - 1 >= 2) {
                        snoopy.y--;
                    }
                    break;

                case 'q':
                case 'Q':
                    system("cls");
                    // Vérifier si une caisse se trouve à gauche de Snoopy
                    canMove = true;
                    for (int i = 0; i < nombreCaisses; i++) {
                        if (caisses[i].x == snoopy.x - 1 && caisses[i].y == snoopy.y) {
                            // Vérifier si l'espace à gauche de la caisse est vide et dans les limites du tableau
                            bool canMoveCaisse = true;
                            for (int j = 0; j < nombreCaisses; j++) {
                                if (caisses[j].x == caisses[i].x - 1 && caisses[j].y == caisses[i].y) {
                                    canMoveCaisse = false; // Ne pas déplacer la caisse
                                    break;
                                }
                            }
                            if (canMoveCaisse && caisses[i].x - 1 >= 50 && !caisses[i].dejaDeplace) { // Ajout de la vérification de dejaDeplace
                                // Déplacer la caisse vers la gauche
                                caisses[i].x--;
                                caisses[i].dejaDeplace = true; // Marquer la caisse comme déjà déplacée
                            } else {
                                canMove = false; // Ne pas déplacer Snoopy si la caisse ne peut pas être déplacée
                            }
                        }
                    }
                    // Déplacer le joueur vers la gauche
                    if (canMove && snoopy.x - 1 >= 50) {
                        snoopy.x--;
                    }
                    break;
                case 's':
                case 'S':
                    system("cls");
                    // Vérifier si une caisse se trouve en dessous de Snoopy
                    canMove = true;
                    for (int i = 0; i < nombreCaisses; i++) {
                        if (caisses[i].x == snoopy.x && caisses[i].y == snoopy.y + 1) {
                            // Vérifier si l'espace en dessous de la caisse est vide et dans les limites du tableau
                            bool canMoveCaisse = true;
                            for (int j = 0; j < nombreCaisses; j++) {
                                if (caisses[j].x == caisses[i].x && caisses[j].y == caisses[i].y + 1) {
                                    canMoveCaisse = false; // Ne pas déplacer la caisse
                                    break;
                                }
                            }
                            if (canMoveCaisse && caisses[i].y + 1 < 13 && !caisses[i].dejaDeplace) { // Ajout de la vérification de dejaDeplace
                                // Déplacer la caisse vers le bas
                                caisses[i].y++;
                                caisses[i].dejaDeplace = true; // Marquer la caisse comme déjà déplacée
                            } else {
                                canMove = false; // Ne pas déplacer Snoopy si la caisse ne peut pas être déplacée
                            }
                        }
                    }
                    // Déplacer le joueur vers le bas
                    if (canMove && snoopy.y + 1 < 13) {
                        snoopy.y++;
                    }
                    break;
                case 'd':
                case 'D':
                    system("cls");
                    // Vérifier si une caisse se trouve à droite de Snoopy
                    canMove = true;
                    for (int i = 0; i < nombreCaisses; i++) {
                        if (caisses[i].x == snoopy.x + 1 && caisses[i].y == snoopy.y) {
                            // Vérifier si l'espace à droite de la caisse est vide et dans les limites du tableau
                            bool canMoveCaisse = true;
                            for (int j = 0; j < nombreCaisses; j++) {
                                if (caisses[j].x == caisses[i].x + 1 && caisses[j].y == caisses[i].y) {
                                    canMoveCaisse = false; // Ne pas déplacer la caisse
                                    break;
                                }
                            }
                            if (canMoveCaisse && caisses[i].x + 1 < 71 && !caisses[i].dejaDeplace) { // Ajout de la vérification de dejaDeplace
                                // Déplacer la caisse vers la droite
                                caisses[i].x++;
                                caisses[i].dejaDeplace = true; // Marquer la caisse comme déjà déplacée
                            } else {
                                canMove = false; // Ne pas déplacer Snoopy si la caisse ne peut pas être déplacée
                            }
                        }
                    }
                    // Déplacer le joueur vers la droite
                    if (canMove && snoopy.x + 1 < 71) {
                        snoopy.x++;
                    }
                    break;
            }
        }
    }
}


void Niv2(int *score, int *vie){
    time_t start_time = time(NULL);
    system("cls");
    srand(time(NULL)); // Initialiser la graine pour la génération de nombres aléatoires
    // Initialisation de Snoopy
    struct Snoopy snoopy = {60, 7, 3, 0};

    // Initialisation des oiseaux
    struct Oiseau oiseaux[4] = {{50, 2},
                                {70, 2},
                                {50, 12},
                                {70, 12}};
    int nombreOiseaux = 4;

    // Initialisation des ennemis
    struct Ennemi ennemis[1] = {{rand() % 21 + 50, rand() % 11 + 2, 1, 1}};
    int nombreEnnemis = 1;

    // Initialisation des caisses
    struct Caisse caisses[12] = {
            {57, 6, false},
            {58, 5, false},
            {59, 4, false},
            {61, 4, false},
            {62, 5, false},
            {63, 6, false},
            {63, 8, false},
            {62, 9, false},
            {61, 10, false},
            {59, 10, false},
            {58, 9, false},
            {57, 8, false}
    };

    if (ennemis[0].x == 60 && ennemis[0].y == 7) {
        system("cls");
        ennemis[0].x = rand() % 21 + 50; // Entre 50 et 70
        ennemis[0].y = rand() % 11 + 2; // Entre 2 et 12  // Entre 8 et 18
    }
    if (ennemis[0].x == 50 && ennemis[0].y == 2) {
        system("cls");
        ennemis[0].x = rand() % 21 + 50; // Entre 50 et 70
        ennemis[0].y = rand() % 11 + 2; // Entre 2 et 12  // Entre 8 et 18
    }
    if (ennemis[0].x == 70 && ennemis[0].y == 2) {
        system("cls");
        ennemis[0].x = rand() % 21 + 50; // Entre 50 et 70
        ennemis[0].y = rand() % 11 + 2; // Entre 2 et 12  // Entre 8 et 18
    }
    if (ennemis[0].x == 50 && ennemis[0].y == 12) {
        system("cls");
        ennemis[0].x = rand() % 21 + 50; // Entre 50 et 70
        ennemis[0].y = rand() % 11 + 2; // Entre 2 et 12  // Entre 8 et 18
    }
    if (ennemis[0].x == 70 && ennemis[0].y == 12) {
        system("cls");
        ennemis[0].x = rand() % 21 + 50; // Entre 50 et 70
        ennemis[0].y = rand() % 11 + 2; // Entre 2 et 12  // Entre 8 et 18
    }
    time_t start_time_enemy = time(NULL);

    char tableau[20][75]; // Déclaration d'un tableau de 20 lignes et 10 colonnes
    for (int ligne = 0; ligne < 20; ligne++) {
        for (int colonne = 0; colonne < 75; colonne++) {
            if ((colonne == 49 || colonne == 71) && (ligne < 14 || ligne > 19) && (ligne < 0 || ligne > 0)) {
                tableau[ligne][colonne] = '|';
            } else if ((ligne == 1 || ligne == 13) && (colonne < 0 || colonne > 47)) {
                tableau[ligne][colonne] = '-';
            } else {
                tableau[ligne][colonne] = ' ';
            }
        }
    }
    int nbroiseaux = 0;
    while (1) {
        bool enPause = false; // Declare enPause here
        // Affichage du tableau avec les éléments initialisés
        printf("\n\n\t\t\t\t\t   ************************************\n");
        printf("\t\t\t\t\t   *\t         NIVEAU 2             *\n");
        printf("\t\t\t\t\t   ************************************\n");
        printf("\t\t\t\t\t\t\t Score: %d\n", *score);
        printf("\t\t\t\t\t\t\t    %d ♥\n", *vie);

        time_t current_time = time(NULL);
        double time_elapsed_in_seconds = difftime(current_time, start_time);
        double remaining_time = 120.0 - time_elapsed_in_seconds;
        printf("\t\t\t\t\t        Temps restant : %.0f secondes\n", remaining_time);

        if (time_elapsed_in_seconds >= 120.0) {
            system("cls");
            Sleep(500);
            printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\t       GAME OVER");

            printf("                                                       Score: %d", *score);
            printf("\tVie: %d ♥", *vie);
            Sleep(3000);
            return;
        }

        for (int ligne = 0; ligne < 20; ligne++) {
            for (int colonne = 0; colonne < 73; colonne++) {
                int caisseTrouvee = 0;
                for (int i = 0; i < nombreCaisses; i++) {
                    if (caisses[i].x == colonne && caisses[i].y == ligne) {
                        printf("□"); // Symbole pour une caisse
                        caisseTrouvee = 1;
                        break;
                    }
                }
                if (caisseTrouvee) continue;
                if (snoopy.x == colonne && snoopy.y == ligne) {
                    printf("☺");
                } else if (oiseaux[0].x == colonne && oiseaux[0].y == ligne) {
                    printf("✪");
                } else if (oiseaux[1].x == colonne && oiseaux[1].y == ligne) {
                    printf("✪");
                } else if (oiseaux[2].x == colonne && oiseaux[2].y == ligne) {
                    printf("✪");
                } else if (oiseaux[3].x == colonne && oiseaux[3].y == ligne) {
                    printf("✪");
                } else if (ennemis[0].x == colonne && ennemis[0].y == ligne) {
                    printf("○");
                } else {
                    printf("%c", tableau[ligne][colonne]);
                }
            }
            printf("\n");
        }

        double time_elapsed_in_seconds_enemy = difftime(current_time, start_time_enemy);

        if (time_elapsed_in_seconds_enemy >= 1.0) {
            ennemis[0].x += ennemis[0].dx;
            ennemis[0].y += ennemis[0].dy;
            start_time_enemy = time(NULL); // Réinitialisez le temps de départ après que l'ennemi a bougé
        }
        // Vérifier les collisions avec les murs
        if (ennemis[0].x < 51) {
            ennemis[0].dx *= -1; // Rebondir horizontalement
            ennemis[0].x = 51; // Replacer l'ennemi à l'intérieur des limites
        } else if (ennemis[0].x > 69) {
            ennemis[0].dx *= -1; // Rebondir horizontalement
            ennemis[0].x = 69; // Replacer l'ennemi à l'intérieur des limites
        }
        if (ennemis[0].y < 2) {
            ennemis[0].dy *= -1; // Rebondir verticalement
            ennemis[0].y = 2; // Replacer l'ennemi à l'intérieur des limites
        } else if (ennemis[0].y > 12) {
            ennemis[0].dy *= -1; // Rebondir verticalement
            ennemis[0].y = 12; // Replacer l'ennemi à l'intérieur des limites
        }
        for (int i = 0; i < nombreOiseaux; i++) {
            if (snoopy.x == oiseaux[i].x && snoopy.y == oiseaux[i].y) {
                nbroiseaux = nbroiseaux + 1;
                oiseaux[i].x = -1;
                oiseaux[i].y = -1;
            }
        }

        if (nbroiseaux == 4) {
            niveau = 2;
            double remaining_time = 120.0 - time_elapsed_in_seconds;
            int scoreNiveau = remaining_time * 100;
            *score += scoreNiveau;
            system("cls");
            printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\tBRAVO TU AS REUSSI LE NIVEAU 2");

            printf("\t\t\t\t\t\t\tScore: %d\n", *score);
            Sleep(1500);
            return;
        }
        if (snoopy.x == ennemis[0].x && snoopy.y == ennemis[0].y) {
            *score = *score;
            nbroiseaux = 0;
            *vie -= 1;
            snoopy.x = 60;
            snoopy.y = 7;
            oiseaux[0].x = 50;
            oiseaux[0].y = 2;
            oiseaux[1].x = 70;
            oiseaux[1].y = 2;
            oiseaux[2].x = 50;
            oiseaux[2].y = 12;
            oiseaux[3].x = 70;
            oiseaux[3].y = 12;
            do {
                ennemis[0].x = rand() % 21 + 50;