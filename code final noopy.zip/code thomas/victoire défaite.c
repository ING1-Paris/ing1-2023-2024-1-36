#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <conio.h>
#include "bibinoopy.h"

//void de défaite du niveau 1
void defaiteN1() {
    char matrice[LIGNE][COLONNE];
    printf("****************************************************\n");
    printf("******************* MECHANT NOOPY ! ****************\n");
    printf("*******************   SALETE VA !   ****************\n");
    printf("****************************************************\n\n");
    printf("****************************************************\n");
    printf("************** QUE VOULEZ VOUS FAIRE ? *************\n");
    printf("****************************************************\n");
    printf("1. RECOMMENCER\n");
    printf("2. SCORES\n");
    printf("3. RETOUR AU MENU\n");
    printf("****************************************************\n");

    int choix2;
    choix2 = getch();

    switch (choix2) {
        case '1':
            system("cls");
            NIVEAU1(matrice);
            break;
        case '2':
            system("cls");
            break;
        case '3':
            system("cls");
            Menu();
            break;
        default:
            printf("Choix non valide\n");
            break;
    }
}

//void de victoire du niveau 1
void victoireN1() {
    int seconde =120;
    char matrice[LIGNE][COLONNE];
    system("cls");
    printf("****************************************************\n");
    printf("*** BRAVO NOOPY TU AS ATTRAPE TOUS LES OISEAUX ! ***\n");
    printf("********* TU ES UN BON LAPIN DE GARENNE ! **********\n");
    printf("****************************************************\n\n");
    printf("****************************************************\n");
    printf("************* QUE VOULEZ VOUS FAIRE ? **************\n");
    printf("1. PROCHAIN NIVEAU\n");
    printf("2. REJOUER\n");
    printf("3. NOUVEAU JEU\n");
    printf("4. SCORES\n");
    printf("5. RETOUR AU MENU\n");
    printf("****************************************************\n");
    printf("****************************************************\n");


    int choix1;
    choix1 = getch();

    switch (choix1) {
        case '1':
            system("cls");
            NIVEAU2(matrice);
            break;
        case '2':
            system("cls");
            NIVEAU1(matrice);
            break;
        case '3':
            system("cls");
            NIVEAU1(matrice);
            break;
        case '4':
            system("cls");
            // Ajoutez le code pour afficher les scores ou effectuez d'autres actions nécessaires
            break;
        case '5':
            system("cls");
            Menu();
            break;
        default:
            printf("Choix non valide\n");
            break;
    }
}

//void de défaite du niveau 2
void defaiteN2() {
    char motrice[LIGNE][COLONNE];
    printf("****************************************************\n");
    printf("******************* MECHANT NOOPY ! ****************\n");
    printf("*******************   SALETE VA !   ****************\n");
    printf("****************************************************\n\n");
    printf("****************************************************\n");
    printf("************** QUE VOULEZ VOUS FAIRE ? *************\n");
    printf("****************************************************\n");
    printf("1. RECOMMENCER\n");
    printf("2. SCORES\n");
    printf("3. RETOUR AU MENU\n");
    printf("****************************************************\n");
    int choix2;
    choix2 = getch();
    switch (choix2) {
        case '1':
            system("cls");
            NIVEAU2(motrice);
            break;
        case '2':
            system("cls");
            break;
        case '3':
            system("cls");
            Menu();
            break;
        default:
            printf("Choix non valide\n");
            break;
    }
}

//void de victoire niveau 2
void victoireN2() {
    char motrice[LIGNE][COLONNE];
    system("cls");
    printf("****************************************************\n");
    printf("*** BRAVO NOOPY TU AS ATTRAPE TOUS LES OISEAUX ! ***\n");
    printf("********* TU ES UN BON LAPIN DE GARENNE ! **********\n");
    printf("****************************************************\n\n");
    printf("****************************************************\n");
    printf("************* QUE VOULEZ VOUS FAIRE ? **************\n");
    printf("1. PROCHAIN NIVEAU\n");
    printf("2. REJOUER\n");
    printf("3. NOUVEAU JEU\n");
    printf("4. SCORES\n");
    printf("5. RETOUR AU MENU\n");
    printf("****************************************************\n");
    printf("****************************************************\n");
    int choix1;
    choix1 = getch();
    switch (choix1) {
        case '1':
            system("cls");
            NIVEAU3(motrice);
            break;
        case '2':
            system("cls");
            NIVEAU2(motrice);
            break;
        case '3':
            system("cls");
            NIVEAU1(motrice);
            break;
        case '4':
            system("cls");
            // Handle scores
            break;
        case '5':
            system("cls");
            Menu();
            break;
        default:
            printf("Choix non valide\n");
            break;
    }
}

//void de défaite du niveau 3
void defaiteN3() {
    char matrice[LIGNE][COLONNE];
    printf("****************************************************\n");
    printf("******************* MECHANT NOOPY ! ****************\n");
    printf("*******************   SALETE VA !   ****************\n");
    printf("****************************************************\n\n");
    printf("****************************************************\n");
    printf("************** QUE VOULEZ VOUS FAIRE ? *************\n");
    printf("****************************************************\n");
    printf("1. RECOMMENCER\n");
    printf("2. SCORES\n");
    printf("3. RETOUR AU MENU\n");
    printf("****************************************************\n");
    int choix2;
    choix2 = getch();
    switch (choix2) {
        case '1':
            system("cls");
            NIVEAU3(matrice);
            break;
        case '2':
            system("cls");
            break;
        case '3':
            system("cls");
            Menu();
            break;
        default:
            printf("Choix non valide\n");
            break;
    }
}

//void de victoire niveau 3
void victoireN3() {
    char matrice[LIGNE][COLONNE];
    system("cls");
    printf("****************************************************\n");
    printf("*** BRAVO NOOPY TU AS ATTRAPE TOUS LES OISEAUX ! ***\n");
    printf("********* TU ES UN BON LAPIN DE GARENNE ! **********\n");
    printf("****************************************************\n\n");
    printf("****************************************************\n");
    printf("************* QUE VOULEZ VOUS FAIRE ? **************\n");
    printf("1. PROCHAIN NIVEAU\n");
    printf("2. REJOUER\n");
    printf("3. NOUVEAU JEU\n");
    printf("4. SCORES\n");
    printf("5. RETOUR AU MENU\n");
    printf("****************************************************\n");
    printf("****************************************************\n");
    int choix1;
    choix1 = getch();
    switch (choix1) {
        case '1':
            system("cls");
            NIVEAU4(matrice);
            break;
        case '2':
            system("cls");
            NIVEAU3(matrice);
            break;
        case '3':
            system("cls");
            NIVEAU1(matrice);
            break;
        case '4':
            system("cls");
            // Handle scores
            break;
        case '5':
            system("cls");
            Menu();
            break;
        default:
            printf("Choix non valide\n");
            break;
    }
}


//void de défaite du niveau 4
void defaiteN4() {
    char matrice[LIGNE][COLONNE];
    printf("****************************************************\n");
    printf("******************* MECHANT NOOPY ! ****************\n");
    printf("*******************   SALETE VA !   ****************\n");
    printf("****************************************************\n\n");
    printf("****************************************************\n");
    printf("************** QUE VOULEZ VOUS FAIRE ? *************\n");
    printf("****************************************************\n");
    printf("1. RECOMMENCER\n");
    printf("2. SCORES\n");
    printf("3. RETOUR AU MENU\n");
    printf("****************************************************\n");
    int choix2;
    choix2 = getch();
    switch (choix2) {
        case '1':
            system("cls");
            NIVEAU4(matrice);
            break;
        case '2':
            system("cls");
            break;
        case '3':
            system("cls");
            Menu();
            break;
        default:
            printf("Choix non valide\n");
            break;
    }
}

//void de victoire niveau 4
void victoireN4() {
    char matrice[LIGNE][COLONNE];
    system("cls");
    printf("****************************************************\n");
    printf("*** BRAVO NOOPY TU AS ATTRAPE TOUS LES OISEAUX ! ***\n");
    printf("********* TU ES UN BON LAPIN DE GARENNE ! **********\n");
    printf("****************************************************\n\n");
    printf("****************************************************\n");
    printf("************* QUE VOULEZ VOUS FAIRE ? **************\n");
    printf("1. PROCHAIN NIVEAU\n");
    printf("2. REJOUER\n");
    printf("3. NOUVEAU JEU\n");
    printf("4. SCORES\n");
    printf("5. RETOUR AU MENU\n");
    printf("****************************************************\n");
    printf("****************************************************\n");
    int choix1;
    choix1 = getch();
    switch (choix1) {
        case '1':
            system("cls");
            NIVEAU4(matrice);
            break;
        case '2':
            system("cls");
            NIVEAU4(matrice);
            break;
        case '3':
            system("cls");
            NIVEAU1(matrice);
            break;
        case '4':
            system("cls");
            // Handle scores
            break;
        case '5':
            system("cls");
            Menu();
            break;
        default:
            printf("Choix non valide\n");
            break;
    }
}