#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <conio.h>
#include "bibinoopy.h"
//fonction qui affiche le menu
int Menu(void) {
    int NBRoiseau, NBRvie, x, y, seconds;
    int choix;
    int retour;
    char matrice[LIGNE][COLONNE];
    struct profil joueur;
    printf("***********************************************\n");
    printf("****************** SNOOPY GAME ****************\n");
    printf("***********************************************\n");
    printf("1. REGLES DU JEU\n");
    printf("2. NOUVEAU JEU\n");
    printf("3. CHARGER UNE PARTIE\n");
    printf("4. CONFIGURATION IDENTIFIANT ET MOT DE PASSE\n");
    printf("5. SCORES\n");
    printf("6. QUITTER\n");
    printf("***********************************************\n");
    printf("***********************************************\n");
    printf("***********************************************\n");

    choix = getch();

    switch (choix) {
        case '1':
            system("cls");
            reglesDuJeu();
            printf("retour : 1");
            scanf("%d", &retour);
            if (retour == 1) {
                Menu();
            }
            break;
        case '2':
            system("cls");
            connexion(joueur);
            system("cls");
            NIVEAU1(matrice);
            break;
        case '3':
            chargerNiveau(matrice, &NBRoiseau, &NBRvie, &x, &y, &seconds);
            break;
        case '4':
            system("cls");
            joueur = motDePasse();
            Menu();
            break;
        case '5':
            system("cls");
            break;
        case '6':
            system("cls");
            printf("Au revoir !\n");
            break;
        default:
            printf("Choix non valide\n");
            break;
    }

    return 0;
}

//fonction qui affiche les règles du jeu
void reglesDuJeu(void) {
    printf("Le but de Snoopy est de récupérer 4 oiseaux aux 4 coins du niveau en un temps imparti. Le problème\n"
           "est que ces 4 oiseaux ne sont pas si faciles à récupérer. Une balle rebondit constamment dans le niveau\n"
           "afin de freiner Snoopy dans sa quête. Mais ce n'est pas tout, d'autres pièges sont présents comme des\n"
           "téléporteurs que la balle peut emprunter ou des cases piégées, voir même des blocs à pousser ou à\n"
           "casser...\n");
}

//fonction qui permet de commencer une nouvelle parti
void nouveauJeu(struct profil joueur) {
    char matrice[LIGNE][COLONNE];
    // Appel de la fonction de connexion avec le profil du joueur
    int authentification = connexion(joueur);
    if (authentification) {
        printf("authentification réussie\n");
        affichage(matrice);
        NIVEAU1(matrice);
    } else {
        printf("Identifiant ou mot de passe incorrect\n");
    }
}

//qui permet de se connecter à une parti
int connexion(struct profil joueur) {
    char identifiantDeCo[100];
    char MDPDeCo[100];
    int authentificationReussie = 0;

    do {
        printf("Identifiant : ");
        scanf("%s", identifiantDeCo);
        printf("Mot de passe : ");
        scanf("%s", MDPDeCo);

        if (strcmp(identifiantDeCo, joueur.identifiant) == 0 && strcmp(MDPDeCo, joueur.MDP) == 0) {
            authentificationReussie = 0;
        } else {
            authentificationReussie = 1;
        }
    } while (!authentificationReussie);

    return authentificationReussie;
}

//
struct profil motDePasse(void) {
    struct profil joueur = {"", "", ""};
    printf("Choisir votre identifiant : ");
    scanf("%s", joueur.identifiant);
    printf("Choisir votre mot de passe : ");
    scanf("%s", joueur.MDP);
    printf("Choisir un pseudo : ");
    scanf("%s", joueur.pseudo);
    system("cls");
    return joueur;
}

void chargerPartie(void) {
    int A;
    for (A = 120; A > 0; A = A - 1) {
        system("cls");
        printf("TIMER : %d", A);
        sleep(1);
    }
}

void affichermotrice(char motrice[LIGNE][COLONNE]){
    for (int i = 0; i < LIGNE; i++) {
        for (int j = 0; j < COLONNE; j++) {
            printf("%c", motrice[i][j]);
        }
        printf("\n");
    }
}

void affichage(char matrice[LIGNE][COLONNE]) {
    for (int i = 0; i < LIGNE; i++) {
        for (int j = 0; j < COLONNE; j++) {
            printf("%c", matrice[i][j]); // Affiche les bordures du tableau
        }
        printf("\n");  // Passer à la ligne suivante
    }
}


void afficherScore (int scoreFinal){
    printf("le score final : %d\n",scoreFinal);

}

void sauvegarderNiveau(char matrice[LIGNE][COLONNE], int NBRoiseau, int NBRvie, int x, int y, int seconds) {
    FILE *fichier = fopen("../sauvegarde.txt", "w");

    if (fichier == NULL) {
        printf("Erreur lors de l'ouverture du fichier de sauvegarde.\n");
        return;
    }

    // Écriture des données dans le fichier
    fprintf(fichier, "%d %d %d %d %d\n", NBRoiseau, NBRvie, x, y, seconds);

    for (int i = 0; i < LIGNE; i++) {
        for (int j = 0; j < COLONNE; j++) {
            fprintf(fichier, "%c", matrice[i][j]);
        }
        fprintf(fichier, "\n");
    }

    fclose(fichier);
    printf("Sauvegarde effectuée. Retour au menu...\n");
    sleep(2);  // Pause de 2 secondes pour que l'utilisateur puisse voir le message
    Menu();
}
void chargerNiveau(char matrice[LIGNE][COLONNE], int *NBRoiseau, int *NBRvie, int *x, int *y, int *seconds) {
    FILE *fichier = fopen("../sauvegarde.txt", "r");

    if (fichier == NULL) {
        printf("Aucune sauvegarde trouvée.\n");
        return;
    }

    // Lecture des données depuis le fichier
    fscanf(fichier, "%d %d %d %d %d", NBRoiseau, NBRvie, x, y, seconds);

    for (int i = 0; i < LIGNE; i++) {
        for (int j = 0; j < COLONNE; j++) {
            fscanf(fichier, "%c", &matrice[i][j]);
        }
    }

    fclose(fichier);
}
void timer(void) {
    int seconds;
    int seconde = 120;
    if (seconds > 0) {
        usleep(100000);
        (seconds)--;
    }
    if (seconds - 100) {
        (seconde)--;
        printf("\r"); // Retour au début de la ligne pour écraser le texte précédent
        printf("\r\t\t\t\t\tTemps restant : %d secondes", seconde);
        printf("\r"); // Retour au début de la ligne pour écraser le texte précédent
    }
}