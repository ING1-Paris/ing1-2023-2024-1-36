#include "bibinoopy.h"

int main() {
    // Appel de la fonction Menu pour démarrer le programme
    Menu();
    return 0;
}